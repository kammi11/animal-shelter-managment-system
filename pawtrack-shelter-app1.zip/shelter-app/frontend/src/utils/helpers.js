export function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

export function daysAgo(dateStr) {
  if (!dateStr) return 0;
  const diff = Date.now() - new Date(dateStr).getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

export function getInitials(name = '') {
  return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
}

export function getHealthBadgeClass(status) {
  const map = {
    healthy: 'badge-success',
    unhealthy: 'badge-danger',
    under_treatment: 'badge-warning',
    critical: 'badge-danger',
  };
  return map[status] || 'badge-neutral';
}

export function getStatusBadgeClass(status) {
  const map = {
    in_shelter: 'badge-info',
    adopted: 'badge-success',
    deceased: 'badge-neutral',
    transferred: 'badge-warning',
  };
  return map[status] || 'badge-neutral';
}

export function getStatusLabel(status) {
  const map = {
    in_shelter: 'In Shelter',
    adopted: 'Adopted',
    deceased: 'Deceased',
    transferred: 'Transferred',
  };
  return map[status] || status;
}

export function getHealthLabel(status) {
  const map = {
    healthy: 'Healthy',
    unhealthy: 'Unhealthy',
    under_treatment: 'Under Treatment',
    critical: 'Critical',
  };
  return map[status] || status;
}

export function getSpeciesEmoji(species) {
  const map = {
    dog: '🐕',
    cat: '🐈',
    bird: '🦜',
    rabbit: '🐇',
    hamster: '🐹',
    fish: '🐟',
    reptile: '🦎',
    other: '🐾',
  };
  const key = (species || '').toLowerCase();
  return map[key] || '🐾';
}

export function getRoleColor(role) {
  const map = {
    admin: '#7c3aed',
    staff: '#2563eb',
    veterinarian: '#059669',
    volunteer: '#d97706',
  };
  return map[role] || '#6b7280';
}

export function getDaysLabel(days) {
  if (days === 0) return 'Today';
  if (days === 1) return '1 day';
  return `${days} days`;
}

export function isVaccinationOverdue(nextDueDate) {
  if (!nextDueDate) return false;
  return new Date(nextDueDate) < new Date();
}

export function photoUrl(url) {
  if (!url) return null;
  if (url.startsWith('http')) return url;
  return url;
}
