import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import Dashboard from './pages/Dashboard';
import AnimalsPage from './pages/AnimalsPage';
import AnimalDetail from './pages/AnimalDetail';
import AddAnimalPage from './pages/AddAnimalPage';
import SearchPage from './pages/SearchPage';
import AdoptionsPage from './pages/AdoptionsPage';
import ReportsPage from './pages/ReportsPage';
import UsersPage from './pages/UsersPage';
import ProfilePage from './pages/ProfilePage';

function PrivateRoute({ children, roles }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="loading-center"><div className="spinner" /></div>;
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return children;
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <LoginPage />} />
      <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
        <Route index element={<Dashboard />} />
        <Route path="animals" element={<AnimalsPage />} />
        <Route path="animals/add" element={<PrivateRoute roles={['admin','staff','veterinarian']}><AddAnimalPage /></PrivateRoute>} />
        <Route path="animals/:id" element={<AnimalDetail />} />
        <Route path="search" element={<SearchPage />} />
        <Route path="adoptions" element={<AdoptionsPage />} />
        <Route path="reports" element={<ReportsPage />} />
        <Route path="users" element={<PrivateRoute roles={['admin']}><UsersPage /></PrivateRoute>} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
        <Toaster position="top-right" toastOptions={{
          style: { fontFamily: 'DM Sans, sans-serif', fontSize: 14, borderRadius: 10 },
          success: { iconTheme: { primary: '#1a5c3a', secondary: 'white' } }
        }} />
      </BrowserRouter>
    </AuthProvider>
  );
}
