import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getInitials, getRoleColor } from '../utils/helpers';
import {
  LayoutDashboard, PawPrint, Search, Heart, BarChart2,
  Users, LogOut, Menu, X, Bell, ChevronDown, User, Settings
} from 'lucide-react';

const navItems = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard', exact: true },
  { path: '/animals', icon: PawPrint, label: 'Animals' },
  { path: '/search', icon: Search, label: 'Tag Search' },
  { path: '/adoptions', icon: Heart, label: 'Adoptions' },
  { path: '/reports', icon: BarChart2, label: 'Reports' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };

  const SidebarContent = () => (
    <>
      {/* Logo */}
      <div style={{ padding: '28px 24px 20px', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 12,
            background: 'rgba(245,166,35,0.2)', display: 'flex',
            alignItems: 'center', justifyContent: 'center', fontSize: 22
          }}>🐾</div>
          <div>
            <div style={{ fontFamily: 'DM Serif Display, serif', fontSize: 20, color: 'white', lineHeight: 1 }}>PawTrack</div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 2 }}>Shelter Management</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '16px 12px', display: 'flex', flexDirection: 'column', gap: 4 }}>
        {navItems.map(({ path, icon: Icon, label, exact }) => (
          <NavLink key={path} to={path} end={exact}
            onClick={() => setSidebarOpen(false)}
            style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 14px', borderRadius: 10,
              color: isActive ? 'white' : 'rgba(255,255,255,0.6)',
              background: isActive ? 'rgba(255,255,255,0.12)' : 'transparent',
              fontWeight: isActive ? 600 : 400,
              fontSize: 15, transition: 'all 0.15s',
              textDecoration: 'none',
            })}>
            <Icon size={18} />
            {label}
          </NavLink>
        ))}

        {user?.role === 'admin' && (
          <NavLink to="/users" onClick={() => setSidebarOpen(false)}
            style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 14px', borderRadius: 10,
              color: isActive ? 'white' : 'rgba(255,255,255,0.6)',
              background: isActive ? 'rgba(255,255,255,0.12)' : 'transparent',
              fontWeight: isActive ? 600 : 400,
              fontSize: 15, transition: 'all 0.15s', textDecoration: 'none',
            })}>
            <Users size={18} />
            Staff & Users
          </NavLink>
        )}
      </nav>

      {/* User info at bottom */}
      <div style={{ padding: '16px 12px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '10px 14px', borderRadius: 10,
          background: 'rgba(255,255,255,0.07)',
        }}>
          <div className="avatar" style={{ background: getRoleColor(user?.role), width: 34, height: 34, fontSize: 12 }}>
            {getInitials(user?.full_name)}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: 'white', fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {user?.full_name}
            </div>
            <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 11, textTransform: 'capitalize' }}>{user?.role}</div>
          </div>
        </div>
        <button onClick={handleLogout}
          style={{
            width: '100%', marginTop: 6, display: 'flex', alignItems: 'center', gap: 8,
            padding: '9px 14px', border: 'none', borderRadius: 10, cursor: 'pointer',
            background: 'transparent', color: 'rgba(255,255,255,0.5)', fontSize: 14,
            transition: 'all 0.15s', fontFamily: 'DM Sans, sans-serif',
          }}
          onMouseEnter={e => e.currentTarget.style.color = 'white'}
          onMouseLeave={e => e.currentTarget.style.color = 'rgba(255,255,255,0.5)'}
        >
          <LogOut size={16} /> Sign Out
        </button>
      </div>
    </>
  );

  return (
    <div className="sidebar-layout">
      {/* Desktop sidebar */}
      <div className="sidebar" style={{ display: 'flex', flexDirection: 'column' }}>
        <SidebarContent />
      </div>

      {/* Mobile sidebar */}
      {sidebarOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 200, display: 'flex' }}>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.5)' }}
            onClick={() => setSidebarOpen(false)} />
          <div style={{
            position: 'relative', width: 260, background: 'var(--bg-sidebar)',
            display: 'flex', flexDirection: 'column', zIndex: 1,
          }}>
            <button onClick={() => setSidebarOpen(false)}
              style={{ position: 'absolute', top: 16, right: 16, background: 'none', border: 'none', color: 'white', cursor: 'pointer' }}>
              <X size={22} />
            </button>
            <SidebarContent />
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="main-content">
        {/* Topbar */}
        <div className="topbar">
          <button className="btn btn-ghost btn-icon"
            style={{ display: 'none' }}
            id="mobile-menu-btn"
            onClick={() => setSidebarOpen(true)}>
            <Menu size={20} />
          </button>
          <button onClick={() => setSidebarOpen(true)}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              padding: 8, borderRadius: 8, color: 'var(--text)',
              display: 'flex',
            }}
            className="mobile-only">
            <Menu size={22} />
          </button>

          <div style={{ flex: 1 }} />

          <div style={{ display: 'flex', alignItems: 'center', gap: 12, position: 'relative' }}>
            <button onClick={() => navigate('/profile')}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                background: 'none', border: 'none', cursor: 'pointer',
                padding: '6px 10px', borderRadius: 10,
                color: 'var(--text)', fontFamily: 'DM Sans, sans-serif',
              }}>
              <div className="avatar" style={{ background: getRoleColor(user?.role), width: 32, height: 32, fontSize: 12 }}>
                {getInitials(user?.full_name)}
              </div>
              <span style={{ fontSize: 14, fontWeight: 600 }}>{user?.full_name}</span>
              <ChevronDown size={14} color="var(--text-muted)" />
            </button>
          </div>
        </div>

        {/* Page content */}
        <div className="page-content">
          <Outlet />
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .mobile-only { display: flex !important; }
        }
        @media (min-width: 901px) {
          .mobile-only { display: none !important; }
        }
      `}</style>
    </div>
  );
}
