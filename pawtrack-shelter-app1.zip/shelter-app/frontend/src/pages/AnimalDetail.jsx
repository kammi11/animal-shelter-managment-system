import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import {
  formatDate, getSpeciesEmoji, getHealthBadgeClass, getHealthLabel,
  getStatusBadgeClass, getStatusLabel, isVaccinationOverdue
} from '../utils/helpers';
import {
  ArrowLeft, Edit2, Trash2, QrCode, Syringe, Stethoscope,
  Heart, Plus, Save, X, Download, Calendar, MapPin, Weight,
  AlertTriangle, CheckCircle, Camera, Upload
} from 'lucide-react';

function QRModal({ animal, onClose }) {
  const [qr, setQr] = useState(null);
  useEffect(() => {
    api.get(`/animals/${animal.id}/qrcode`).then(r => setQr(r.data));
  }, [animal.id]);

  const download = () => {
    const link = document.createElement('a');
    link.href = qr.qrCode;
    link.download = `qr-${qr.tag_number}.png`;
    link.click();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" style={{ maxWidth: 340 }} onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>QR Code — {animal.name}</h2>
          <button className="btn btn-ghost btn-icon btn-sm" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="modal-body" style={{ textAlign: 'center' }}>
          {!qr ? <div className="loading-center"><div className="spinner" /></div> : (
            <>
              <img src={qr.qrCode} alt="QR Code" style={{ width: 220, height: 220, borderRadius: 12 }} />
              <div style={{ marginTop: 12, fontFamily: 'Courier New', fontWeight: 700, fontSize: 18, letterSpacing: '0.08em' }}>
                {qr.tag_number}
              </div>
              <div style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 4 }}>
                Scan to look up this animal instantly
              </div>
            </>
          )}
        </div>
        <div className="modal-footer">
          <button className="btn btn-ghost" onClick={onClose}>Close</button>
          {qr && <button className="btn btn-primary" onClick={download}><Download size={16} /> Download</button>}
        </div>
      </div>
    </div>
  );
}

function AddMedicalModal({ animalId, onClose, onSaved }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    record_type: 'checkup', title: '', description: '', vet_name: user?.full_name || '',
    visit_date: new Date().toISOString().split('T')[0], medications: '',
    follow_up_date: '', health_status: '',
  });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/medical', { ...form, animal_id: animalId });
      toast.success('Medical record added');
      onSaved();
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save');
    } finally { setSaving(false); }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Add Medical Record</h2>
          <button className="btn btn-ghost btn-icon btn-sm" onClick={onClose}><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Record Type *</label>
                <select className="form-control" value={form.record_type} onChange={e => set('record_type', e.target.value)}>
                  {['checkup','diagnosis','treatment','surgery','other'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Visit Date</label>
                <input className="form-control" type="date" value={form.visit_date} onChange={e => set('visit_date', e.target.value)} />
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Title *</label>
              <input className="form-control" placeholder="Brief summary" required value={form.title} onChange={e => set('title', e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea className="form-control" rows={3} placeholder="Detailed notes…" value={form.description} onChange={e => set('description', e.target.value)} />
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Vet Name</label>
                <input className="form-control" value={form.vet_name} onChange={e => set('vet_name', e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Follow-up Date</label>
                <input className="form-control" type="date" value={form.follow_up_date} onChange={e => set('follow_up_date', e.target.value)} />
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Medications</label>
              <input className="form-control" placeholder="e.g. Amoxicillin 250mg" value={form.medications} onChange={e => set('medications', e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label">Update Health Status</label>
              <select className="form-control" value={form.health_status} onChange={e => set('health_status', e.target.value)}>
                <option value="">— No change —</option>
                <option value="healthy">Healthy</option>
                <option value="unhealthy">Unhealthy</option>
                <option value="under_treatment">Under Treatment</option>
                <option value="critical">Critical</option>
              </select>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? <div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> : <Save size={16} />}
              Save Record
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function AddVaccinationModal({ animalId, onClose, onSaved }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    vaccine_name: '', administered_date: new Date().toISOString().split('T')[0],
    next_due_date: '', administered_by: user?.full_name || '', batch_number: '', notes: '',
  });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/vaccinations', { ...form, animal_id: animalId });
      toast.success('Vaccination recorded');
      onSaved();
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save');
    } finally { setSaving(false); }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Record Vaccination</h2>
          <button className="btn btn-ghost btn-icon btn-sm" onClick={onClose}><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="form-group">
              <label className="form-label">Vaccine Name *</label>
              <input className="form-control" placeholder="e.g. Rabies, DHPP" required value={form.vaccine_name} onChange={e => set('vaccine_name', e.target.value)} />
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Date Administered</label>
                <input className="form-control" type="date" value={form.administered_date} onChange={e => set('administered_date', e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Next Due Date</label>
                <input className="form-control" type="date" value={form.next_due_date} onChange={e => set('next_due_date', e.target.value)} />
              </div>
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Administered By</label>
                <input className="form-control" value={form.administered_by} onChange={e => set('administered_by', e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Batch Number</label>
                <input className="form-control" placeholder="Optional" value={form.batch_number} onChange={e => set('batch_number', e.target.value)} />
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Notes</label>
              <textarea className="form-control" rows={2} value={form.notes} onChange={e => set('notes', e.target.value)} />
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? <div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> : <Syringe size={16} />}
              Record Vaccination
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function AdoptionModal({ animal, onClose, onSaved }) {
  const { user } = useAuth();
  const [form, setForm] = useState({
    adopter_name: '', adopter_email: '', adopter_phone: '',
    adopter_address: '', adoption_date: new Date().toISOString().split('T')[0],
    adoption_fee: '', notes: '',
  });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/adoptions', { ...form, animal_id: animal.id });
      toast.success(`${animal.name} successfully adopted! 🎉`);
      onSaved();
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to process adoption');
    } finally { setSaving(false); }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Process Adoption — {animal.name}</h2>
          <button className="btn btn-ghost btn-icon btn-sm" onClick={onClose}><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="alert-banner alert-banner-info">
              <CheckCircle size={16} style={{ flexShrink: 0 }} />
              This will mark <strong>{animal.name}</strong> as adopted and remove them from available animals.
            </div>
            <div className="form-group">
              <label className="form-label">Adopter Full Name *</label>
              <input className="form-control" required value={form.adopter_name} onChange={e => set('adopter_name', e.target.value)} />
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Email</label>
                <input className="form-control" type="email" value={form.adopter_email} onChange={e => set('adopter_email', e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Phone</label>
                <input className="form-control" value={form.adopter_phone} onChange={e => set('adopter_phone', e.target.value)} />
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Address</label>
              <input className="form-control" value={form.adopter_address} onChange={e => set('adopter_address', e.target.value)} />
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label className="form-label">Adoption Date</label>
                <input className="form-control" type="date" value={form.adoption_date} onChange={e => set('adoption_date', e.target.value)} />
              </div>
              <div className="form-group">
                <label className="form-label">Adoption Fee ($)</label>
                <input className="form-control" type="number" min="0" step="0.01" value={form.adoption_fee} onChange={e => set('adoption_fee', e.target.value)} />
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Notes</label>
              <textarea className="form-control" rows={2} value={form.notes} onChange={e => set('notes', e.target.value)} />
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? <div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> : <Heart size={16} />}
              Complete Adoption
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function AnimalDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [animal, setAnimal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [showQR, setShowQR] = useState(false);
  const [showMedModal, setShowMedModal] = useState(false);
  const [showVaccModal, setShowVaccModal] = useState(false);
  const [showAdoptModal, setShowAdoptModal] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({});
  const fileRef = useRef();
  const [newPhoto, setNewPhoto] = useState(null);

  useEffect(() => { load(); }, [id]);

  const load = async () => {
    const r = await api.get(`/animals/${id}`);
    setAnimal(r.data);
    setEditForm(r.data);
    setLoading(false);
  };

  const saveEdit = async () => {
    try {
      const fd = new FormData();
      const fields = ['name','species','breed','gender','age_years','age_months','weight_kg','color','entry_date','cage_location','status','health_status','notes'];
      fields.forEach(k => { if (editForm[k] !== undefined) fd.append(k, editForm[k] ?? ''); });
      if (newPhoto) fd.append('photo', newPhoto);
      await api.put(`/animals/${id}`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success('Animal updated');
      setEditing(false);
      setNewPhoto(null);
      load();
    } catch (err) { toast.error(err.response?.data?.error || 'Update failed'); }
  };

  const deleteAnimal = async () => {
    if (!confirm(`Delete ${animal.name} permanently? This cannot be undone.`)) return;
    await api.delete(`/animals/${id}`);
    toast.success('Animal deleted');
    navigate('/animals');
  };

  if (loading) return <div className="loading-center"><div className="spinner" /><span>Loading…</span></div>;
  if (!animal) return <div className="empty-state"><p>Animal not found</p></div>;

  const canEdit = ['admin','staff','veterinarian'].includes(user?.role);
  const canAdopt = ['admin','staff'].includes(user?.role);

  return (
    <div>
      {/* Back + actions */}
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button className="btn btn-ghost btn-icon" onClick={() => navigate('/animals')}>
            <ArrowLeft size={18} />
          </button>
          <div>
            <h1 className="page-title">{animal.name}</h1>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 4 }}>
              <span className="tag-chip">{animal.tag_number}</span>
              <span className={`badge ${getHealthBadgeClass(animal.health_status)}`}>{getHealthLabel(animal.health_status)}</span>
              <span className={`badge ${getStatusBadgeClass(animal.status)}`}>{getStatusLabel(animal.status)}</span>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button className="btn btn-ghost btn-sm" onClick={() => setShowQR(true)}>
            <QrCode size={16} /> QR Code
          </button>
          {canEdit && !editing && (
            <button className="btn btn-ghost btn-sm" onClick={() => setEditing(true)}>
              <Edit2 size={16} /> Edit
            </button>
          )}
          {editing && (
            <>
              <button className="btn btn-ghost btn-sm" onClick={() => { setEditing(false); setEditForm(animal); setNewPhoto(null); }}>
                <X size={16} /> Cancel
              </button>
              <button className="btn btn-primary btn-sm" onClick={saveEdit}>
                <Save size={16} /> Save Changes
              </button>
            </>
          )}
          {animal.status === 'in_shelter' && canAdopt && (
            <button className="btn btn-accent btn-sm" onClick={() => setShowAdoptModal(true)}>
              <Heart size={16} /> Process Adoption
            </button>
          )}
          {user?.role === 'admin' && (
            <button className="btn btn-danger btn-sm" onClick={deleteAnimal}>
              <Trash2 size={16} />
            </button>
          )}
        </div>
      </div>

      {/* Main layout */}
      <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr', gap: 20 }}>
        {/* Left panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Photo */}
          <div className="card" style={{ padding: 20, textAlign: 'center' }}>
            <div style={{ position: 'relative', display: 'inline-block' }}>
              {(newPhoto ? URL.createObjectURL(newPhoto) : animal.photo_url) ? (
                <img
                  src={newPhoto ? URL.createObjectURL(newPhoto) : animal.photo_url}
                  alt={animal.name}
                  style={{ width: 220, height: 220, borderRadius: 16, objectFit: 'cover', border: '2px solid var(--border)' }}
                />
              ) : (
                <div style={{
                  width: 220, height: 220, borderRadius: 16, background: 'var(--bg)',
                  border: '2px dashed var(--border)', display: 'flex', flexDirection: 'column',
                  alignItems: 'center', justifyContent: 'center', gap: 8, margin: '0 auto',
                }}>
                  <span style={{ fontSize: 56 }}>{getSpeciesEmoji(animal.species)}</span>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>No photo</span>
                </div>
              )}
              {editing && (
                <button
                  onClick={() => fileRef.current.click()}
                  style={{
                    position: 'absolute', bottom: 8, right: 8, background: 'var(--primary)',
                    border: 'none', borderRadius: 8, padding: '6px 10px', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', gap: 4, color: 'white', fontSize: 12,
                  }}>
                  <Camera size={14} /> Change
                </button>
              )}
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }}
              onChange={e => { if (e.target.files[0]) setNewPhoto(e.target.files[0]); }} />

            <div style={{ marginTop: 16 }}>
              <div style={{ fontFamily: 'DM Serif Display, serif', fontSize: 22 }}>{animal.name}</div>
              <div style={{ color: 'var(--text-muted)', fontSize: 14, marginTop: 2, textTransform: 'capitalize' }}>
                {getSpeciesEmoji(animal.species)} {animal.species} {animal.breed ? `· ${animal.breed}` : ''}
              </div>
            </div>

            <div style={{ marginTop: 16, padding: '12px', background: 'var(--bg)', borderRadius: 10 }}>
              <div style={{ fontSize: 28, fontFamily: 'DM Serif Display, serif', color: 'var(--primary-dark)' }}>
                {animal.days_in_shelter}
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>DAYS IN SHELTER</div>
            </div>
          </div>

          {/* Quick info */}
          <div className="card" style={{ padding: 20 }}>
            <div className="section-title">Details</div>
            {[
              { icon: <Calendar size={14} />, label: 'Entry Date', value: formatDate(animal.entry_date) },
              { icon: <MapPin size={14} />, label: 'Location', value: animal.cage_location || '—' },
              { icon: <Weight size={14} />, label: 'Weight', value: animal.weight_kg ? `${animal.weight_kg} kg` : '—' },
              { icon: null, label: 'Gender', value: animal.gender || '—' },
              { icon: null, label: 'Color', value: animal.color || '—' },
              { icon: null, label: 'Age', value: animal.age_years > 0 || animal.age_months > 0 ? `${animal.age_years}y ${animal.age_months}m` : 'Unknown' },
            ].map(({ icon, label, value }) => (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: '1px solid var(--border)', fontSize: 14 }}>
                <span style={{ color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 4 }}>{icon}{label}</span>
                <span style={{ fontWeight: 600, textTransform: 'capitalize' }}>{value}</span>
              </div>
            ))}
          </div>

          {/* Adoption info */}
          {animal.adoption && (
            <div className="card" style={{ padding: 20, background: '#f0fdf4', borderColor: '#bbf7d0' }}>
              <div className="section-title"><Heart size={14} color="var(--success)" /> Adoption Info</div>
              <div style={{ fontSize: 14 }}>
                <div style={{ fontWeight: 700 }}>{animal.adoption.adopter_name}</div>
                <div style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDate(animal.adoption.adoption_date)}</div>
                {animal.adoption.adopter_phone && <div style={{ marginTop: 4, fontSize: 13 }}>{animal.adoption.adopter_phone}</div>}
                {animal.adoption.adopter_email && <div style={{ fontSize: 13 }}>{animal.adoption.adopter_email}</div>}
              </div>
            </div>
          )}
        </div>

        {/* Right panel - tabs */}
        <div>
          {/* Edit form overlay */}
          {editing ? (
            <div className="card" style={{ padding: 24, marginBottom: 16 }}>
              <div className="section-title"><Edit2 size={16} /> Editing Animal</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div className="grid-2">
                  <div className="form-group"><label className="form-label">Name</label>
                    <input className="form-control" value={editForm.name || ''} onChange={e => setEditForm(f => ({ ...f, name: e.target.value }))} />
                  </div>
                  <div className="form-group"><label className="form-label">Breed</label>
                    <input className="form-control" value={editForm.breed || ''} onChange={e => setEditForm(f => ({ ...f, breed: e.target.value }))} />
                  </div>
                </div>
                <div className="grid-2">
                  <div className="form-group"><label className="form-label">Health Status</label>
                    <select className="form-control" value={editForm.health_status || ''} onChange={e => setEditForm(f => ({ ...f, health_status: e.target.value }))}>
                      <option value="healthy">Healthy</option>
                      <option value="unhealthy">Unhealthy</option>
                      <option value="under_treatment">Under Treatment</option>
                      <option value="critical">Critical</option>
                    </select>
                  </div>
                  <div className="form-group"><label className="form-label">Status</label>
                    <select className="form-control" value={editForm.status || ''} onChange={e => setEditForm(f => ({ ...f, status: e.target.value }))}>
                      <option value="in_shelter">In Shelter</option>
                      <option value="adopted">Adopted</option>
                      <option value="transferred">Transferred</option>
                      <option value="deceased">Deceased</option>
                    </select>
                  </div>
                </div>
                <div className="grid-2">
                  <div className="form-group"><label className="form-label">Cage / Location</label>
                    <input className="form-control" value={editForm.cage_location || ''} onChange={e => setEditForm(f => ({ ...f, cage_location: e.target.value }))} />
                  </div>
                  <div className="form-group"><label className="form-label">Weight (kg)</label>
                    <input className="form-control" type="number" step="0.1" value={editForm.weight_kg || ''} onChange={e => setEditForm(f => ({ ...f, weight_kg: e.target.value }))} />
                  </div>
                </div>
                <div className="form-group"><label className="form-label">Notes</label>
                  <textarea className="form-control" rows={3} value={editForm.notes || ''} onChange={e => setEditForm(f => ({ ...f, notes: e.target.value }))} />
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Tabs */}
              <div className="tabs" style={{ marginBottom: 16 }}>
                {[
                  { id: 'overview', label: 'Overview' },
                  { id: 'medical', label: `Medical (${animal.medical_records?.length || 0})` },
                  { id: 'vaccinations', label: `Vaccinations (${animal.vaccinations?.length || 0})` },
                ].map(t => (
                  <button key={t.id} className={`tab-btn ${activeTab === t.id ? 'active' : ''}`}
                    onClick={() => setActiveTab(t.id)}>{t.label}</button>
                ))}
              </div>

              {/* Overview tab */}
              {activeTab === 'overview' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                  {animal.notes && (
                    <div className="card" style={{ padding: 20 }}>
                      <div className="section-title">Notes</div>
                      <p style={{ color: 'var(--text-muted)', fontSize: 14, lineHeight: 1.6 }}>{animal.notes}</p>
                    </div>
                  )}

                  {/* Summary cards */}
                  <div className="grid-2">
                    <div className="card" style={{ padding: 20 }}>
                      <div className="section-title"><Stethoscope size={14} /> Recent Medical</div>
                      {animal.medical_records?.length === 0 ? (
                        <div style={{ color: 'var(--text-muted)', fontSize: 14 }}>No medical records yet</div>
                      ) : animal.medical_records?.slice(0, 3).map(r => (
                        <div key={r.id} style={{ paddingBottom: 10, marginBottom: 10, borderBottom: '1px solid var(--border)', fontSize: 14 }}>
                          <div style={{ fontWeight: 600 }}>{r.title}</div>
                          <div style={{ color: 'var(--text-muted)', fontSize: 12 }}>{r.record_type} · {formatDate(r.visit_date)}</div>
                        </div>
                      ))}
                      <button className="btn btn-ghost btn-sm" style={{ marginTop: 4 }}
                        onClick={() => setActiveTab('medical')}>
                        {canEdit && <Plus size={14} />} View all
                      </button>
                    </div>

                    <div className="card" style={{ padding: 20 }}>
                      <div className="section-title"><Syringe size={14} /> Vaccinations</div>
                      {animal.vaccinations?.length === 0 ? (
                        <div style={{ color: 'var(--text-muted)', fontSize: 14 }}>No vaccinations recorded</div>
                      ) : animal.vaccinations?.slice(0, 3).map(v => (
                        <div key={v.id} style={{ paddingBottom: 10, marginBottom: 10, borderBottom: '1px solid var(--border)', fontSize: 14 }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                            <span style={{ fontWeight: 600 }}>{v.vaccine_name}</span>
                            {isVaccinationOverdue(v.next_due_date) && <AlertTriangle size={14} color="var(--warning)" />}
                          </div>
                          <div style={{ color: 'var(--text-muted)', fontSize: 12 }}>
                            Given: {formatDate(v.administered_date)}
                            {v.next_due_date && ` · Due: ${formatDate(v.next_due_date)}`}
                          </div>
                        </div>
                      ))}
                      <button className="btn btn-ghost btn-sm" style={{ marginTop: 4 }}
                        onClick={() => setActiveTab('vaccinations')}>View all</button>
                    </div>
                  </div>
                </div>
              )}

              {/* Medical records tab */}
              {activeTab === 'medical' && (
                <div>
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 12 }}>
                    {canEdit && (
                      <button className="btn btn-primary btn-sm" onClick={() => setShowMedModal(true)}>
                        <Plus size={14} /> Add Medical Record
                      </button>
                    )}
                  </div>
                  {animal.medical_records?.length === 0 ? (
                    <div className="card">
                      <div className="empty-state">
                        <Stethoscope size={40} />
                        <h3>No medical records</h3>
                        <p>Add the first record for {animal.name}</p>
                        {canEdit && <button className="btn btn-primary btn-sm" onClick={() => setShowMedModal(true)}><Plus size={14} /> Add Record</button>}
                      </div>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                      {animal.medical_records.map(r => (
                        <div key={r.id} className="card" style={{ padding: 18 }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                            <div>
                              <div style={{ fontWeight: 700, fontSize: 15 }}>{r.title}</div>
                              <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
                                <span className="badge badge-info" style={{ fontSize: 11 }}>{r.record_type}</span>
                                <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>{formatDate(r.visit_date)}</span>
                                {r.vet_name && <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>· Dr. {r.vet_name}</span>}
                              </div>
                            </div>
                          </div>
                          {r.description && <p style={{ color: 'var(--text-muted)', fontSize: 14, lineHeight: 1.5, marginBottom: 8 }}>{r.description}</p>}
                          {r.medications && (
                            <div style={{ background: 'var(--bg)', borderRadius: 8, padding: '8px 12px', fontSize: 13 }}>
                              💊 <strong>Medications:</strong> {r.medications}
                            </div>
                          )}
                          {r.follow_up_date && (
                            <div style={{ marginTop: 8, fontSize: 13, color: 'var(--warning)', fontWeight: 600 }}>
                              📅 Follow-up: {formatDate(r.follow_up_date)}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Vaccinations tab */}
              {activeTab === 'vaccinations' && (
                <div>
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 12 }}>
                    {canEdit && (
                      <button className="btn btn-primary btn-sm" onClick={() => setShowVaccModal(true)}>
                        <Plus size={14} /> Record Vaccination
                      </button>
                    )}
                  </div>
                  {animal.vaccinations?.length === 0 ? (
                    <div className="card">
                      <div className="empty-state">
                        <Syringe size={40} />
                        <h3>No vaccinations recorded</h3>
                        {canEdit && <button className="btn btn-primary btn-sm" onClick={() => setShowVaccModal(true)}><Plus size={14} /> Record Vaccination</button>}
                      </div>
                    </div>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                      {animal.vaccinations.map(v => (
                        <div key={v.id} className="card" style={{ padding: 16, display: 'flex', alignItems: 'center', gap: 14 }}>
                          <div style={{ width: 40, height: 40, borderRadius: 10, background: isVaccinationOverdue(v.next_due_date) ? '#fee2e2' : '#d1fae5', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                            {isVaccinationOverdue(v.next_due_date) ? <AlertTriangle size={18} color="var(--danger)" /> : <CheckCircle size={18} color="var(--success)" />}
                          </div>
                          <div style={{ flex: 1 }}>
                            <div style={{ fontWeight: 700 }}>{v.vaccine_name}</div>
                            <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 2 }}>
                              Given: {formatDate(v.administered_date)}
                              {v.administered_by && ` by ${v.administered_by}`}
                            </div>
                            {v.next_due_date && (
                              <div style={{ fontSize: 13, color: isVaccinationOverdue(v.next_due_date) ? 'var(--danger)' : 'var(--success)', fontWeight: 600 }}>
                                {isVaccinationOverdue(v.next_due_date) ? '⚠️ Overdue: ' : 'Next due: '}{formatDate(v.next_due_date)}
                              </div>
                            )}
                          </div>
                          {v.batch_number && <div style={{ fontSize: 12, color: 'var(--text-light)' }}>Batch: {v.batch_number}</div>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Modals */}
      {showQR && <QRModal animal={animal} onClose={() => setShowQR(false)} />}
      {showMedModal && <AddMedicalModal animalId={animal.id} onClose={() => setShowMedModal(false)} onSaved={load} />}
      {showVaccModal && <AddVaccinationModal animalId={animal.id} onClose={() => setShowVaccModal(false)} onSaved={load} />}
      {showAdoptModal && <AdoptionModal animal={animal} onClose={() => setShowAdoptModal(false)} onSaved={load} />}

      <style>{`
        @media (max-width: 900px) {
          div[style*="grid-template-columns: 300px 1fr"] { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}
