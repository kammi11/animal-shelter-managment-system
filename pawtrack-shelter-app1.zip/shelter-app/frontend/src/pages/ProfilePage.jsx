import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { getInitials, getRoleColor, formatDate } from '../utils/helpers';
import { Save, Lock, User } from 'lucide-react';

export default function ProfilePage() {
  const { user } = useAuth();
  const [pwForm, setPwForm] = useState({ current_password: '', new_password: '', confirm_password: '' });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setPwForm(f => ({ ...f, [k]: v }));

  const changePassword = async (e) => {
    e.preventDefault();
    if (pwForm.new_password !== pwForm.confirm_password) {
      toast.error('New passwords do not match');
      return;
    }
    if (pwForm.new_password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    setSaving(true);
    try {
      await api.put('/auth/change-password', {
        current_password: pwForm.current_password,
        new_password: pwForm.new_password,
      });
      toast.success('Password changed successfully');
      setPwForm({ current_password: '', new_password: '', confirm_password: '' });
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to change password');
    } finally { setSaving(false); }
  };

  return (
    <div style={{ maxWidth: 600, margin: '0 auto' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">My Profile</h1>
          <p className="page-subtitle">View your account information</p>
        </div>
      </div>

      {/* Profile card */}
      <div className="card" style={{ padding: 28, marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginBottom: 24 }}>
          <div className="avatar" style={{
            background: getRoleColor(user?.role),
            width: 72, height: 72, fontSize: 24, borderRadius: 18,
          }}>
            {getInitials(user?.full_name)}
          </div>
          <div>
            <h2 style={{ fontFamily: 'DM Serif Display, serif', fontSize: 24 }}>{user?.full_name}</h2>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 4 }}>
              <span style={{
                padding: '3px 12px', borderRadius: 999, fontSize: 13, fontWeight: 700,
                background: getRoleColor(user?.role) + '22', color: getRoleColor(user?.role),
                textTransform: 'capitalize',
              }}>{user?.role}</span>
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {[
            { icon: <User size={15} />, label: 'Username', value: user?.username },
            { icon: null, label: 'Email', value: user?.email },
            { icon: null, label: 'Role', value: user?.role, cap: true },
          ].map(({ icon, label, value, cap }) => (
            <div key={label} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '12px 0', borderBottom: '1px solid var(--border)',
            }}>
              <span style={{ color: 'var(--text-muted)', fontSize: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
                {icon}{label}
              </span>
              <span style={{ fontWeight: 600, fontSize: 15, textTransform: cap ? 'capitalize' : 'none' }}>{value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Change password */}
      <div className="card" style={{ padding: 28 }}>
        <div className="section-title"><Lock size={15} /> Change Password</div>
        <form onSubmit={changePassword} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="form-group">
            <label className="form-label">Current Password</label>
            <input className="form-control" type="password" required
              value={pwForm.current_password} onChange={e => set('current_password', e.target.value)} />
          </div>
          <div className="form-group">
            <label className="form-label">New Password</label>
            <input className="form-control" type="password" required minLength={6}
              value={pwForm.new_password} onChange={e => set('new_password', e.target.value)} />
          </div>
          <div className="form-group">
            <label className="form-label">Confirm New Password</label>
            <input className="form-control" type="password" required
              value={pwForm.confirm_password} onChange={e => set('confirm_password', e.target.value)} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? <div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> : <Save size={16} />}
              Update Password
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
