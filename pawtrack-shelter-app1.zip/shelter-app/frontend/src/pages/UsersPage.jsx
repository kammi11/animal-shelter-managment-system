import React, { useState, useEffect } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { formatDate, getInitials, getRoleColor } from '../utils/helpers';
import { Plus, X, Save, Users, ToggleLeft, ToggleRight } from 'lucide-react';

const ROLES = ['admin','staff','veterinarian','volunteer'];

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ username: '', password: '', full_name: '', email: '', role: 'staff' });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  useEffect(() => { load(); }, []);
  const load = () => api.get('/auth/users').then(r => { setUsers(r.data); setLoading(false); });

  const createUser = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/auth/users', form);
      toast.success('User created successfully');
      setShowModal(false);
      setForm({ username: '', password: '', full_name: '', email: '', role: 'staff' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to create user');
    } finally { setSaving(false); }
  };

  const toggleUser = async (id) => {
    await api.put(`/auth/users/${id}/toggle`);
    toast.success('User status updated');
    load();
  };

  if (loading) return <div className="loading-center"><div className="spinner" /></div>;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Staff & Users</h1>
          <p className="page-subtitle">{users.length} users in the system</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>
          <Plus size={16} /> Add User
        </button>
      </div>

      <div className="card">
        {users.length === 0 ? (
          <div className="empty-state"><Users size={44} /><h3>No users</h3></div>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>User</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div className="avatar" style={{ background: getRoleColor(u.role) }}>{getInitials(u.full_name)}</div>
                      <span style={{ fontWeight: 700 }}>{u.full_name}</span>
                    </div>
                  </td>
                  <td style={{ fontFamily: 'Courier New, monospace', fontWeight: 600 }}>{u.username}</td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{u.email}</td>
                  <td>
                    <span style={{
                      padding: '3px 10px', borderRadius: 999, fontSize: 12, fontWeight: 700,
                      background: getRoleColor(u.role) + '22', color: getRoleColor(u.role),
                      textTransform: 'capitalize',
                    }}>{u.role}</span>
                  </td>
                  <td>
                    <span className={`badge ${u.active ? 'badge-success' : 'badge-danger'}`}>
                      {u.active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDate(u.created_at)}</td>
                  <td>
                    <button className="btn btn-ghost btn-sm" onClick={() => toggleUser(u.id)}
                      title={u.active ? 'Deactivate' : 'Activate'}>
                      {u.active ? <ToggleRight size={18} color="var(--success)" /> : <ToggleLeft size={18} color="var(--danger)" />}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Role legend */}
      <div className="card" style={{ padding: 20, marginTop: 20 }}>
        <div className="section-title">Role Permissions</div>
        <div className="grid-4">
          {[
            { role: 'admin', label: 'Admin', desc: 'Full access: manage users, delete records, all features' },
            { role: 'veterinarian', label: 'Veterinarian', desc: 'Manage medical records, vaccinations, update health status' },
            { role: 'staff', label: 'Staff', desc: 'Add animals, process adoptions, view all records' },
            { role: 'volunteer', label: 'Volunteer', desc: 'View-only access to animal profiles and basic info' },
          ].map(({ role, label, desc }) => (
            <div key={role} style={{ padding: 16, background: 'var(--bg)', borderRadius: 10, border: '1.5px solid var(--border)' }}>
              <div style={{ fontWeight: 700, color: getRoleColor(role), marginBottom: 6, textTransform: 'capitalize' }}>{label}</div>
              <div style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.4 }}>{desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Add user modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Add New User</h2>
              <button className="btn btn-ghost btn-icon btn-sm" onClick={() => setShowModal(false)}><X size={18} /></button>
            </div>
            <form onSubmit={createUser}>
              <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div className="form-group">
                  <label className="form-label">Full Name *</label>
                  <input className="form-control" required value={form.full_name} onChange={e => set('full_name', e.target.value)} />
                </div>
                <div className="grid-2">
                  <div className="form-group">
                    <label className="form-label">Username *</label>
                    <input className="form-control" required value={form.username} onChange={e => set('username', e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Password *</label>
                    <input className="form-control" type="password" required value={form.password} onChange={e => set('password', e.target.value)} />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Email *</label>
                  <input className="form-control" type="email" required value={form.email} onChange={e => set('email', e.target.value)} />
                </div>
                <div className="form-group">
                  <label className="form-label">Role *</label>
                  <select className="form-control" value={form.role} onChange={e => set('role', e.target.value)}>
                    {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                  </select>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>
                  {saving ? <div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> : <Save size={16} />}
                  Create User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
