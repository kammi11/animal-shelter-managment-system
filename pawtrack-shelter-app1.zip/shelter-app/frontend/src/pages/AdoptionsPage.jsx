import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { formatDate, getSpeciesEmoji } from '../utils/helpers';
import { Heart, TrendingUp, DollarSign, Calendar } from 'lucide-react';

export default function AdoptionsPage() {
  const navigate = useNavigate();
  const [adoptions, setAdoptions] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/adoptions'),
      api.get('/adoptions/stats'),
    ]).then(([a, s]) => {
      setAdoptions(a.data);
      setStats(s.data);
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="loading-center"><div className="spinner" /><span>Loading…</span></div>;

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Adoptions</h1>
          <p className="page-subtitle">Track all animal adoptions and records</p>
        </div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid-3" style={{ marginBottom: 24 }}>
          {[
            { label: 'Total Adoptions', value: stats.total_adoptions, icon: Heart, color: '#be185d', bg: '#fce7f3' },
            { label: 'This Month', value: stats.this_month, icon: Calendar, color: '#2563eb', bg: '#dbeafe' },
            { label: 'Total Fees Collected', value: `$${Number(stats.total_fees).toFixed(2)}`, icon: DollarSign, color: '#059669', bg: '#d1fae5' },
          ].map(({ label, value, icon: Icon, color, bg }) => (
            <div className="card stat-card" key={label}>
              <div className="stat-icon" style={{ background: bg, color }}><Icon size={20} /></div>
              <div className="stat-value" style={{ fontSize: typeof value === 'string' && value.length > 8 ? 26 : 36 }}>{value}</div>
              <div className="stat-label">{label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Recent adoptions list */}
      {stats?.recent?.length > 0 && (
        <div className="card" style={{ marginBottom: 20, padding: 20 }}>
          <div className="section-title"><TrendingUp size={16} /> Recent Adoptions</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {stats.recent.map(a => (
              <div key={a.id} style={{ display: 'flex', gap: 14, alignItems: 'center', padding: '12px 0', borderBottom: '1px solid var(--border)' }}
                onClick={() => navigate(`/animals/${a.animal_id}`)} className="hover-row">
                <div style={{ fontSize: 28 }}>{getSpeciesEmoji(a.species)}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700 }}>{a.animal_name}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{a.tag_number} · {a.species}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: 600 }}>{a.adopter_name}</div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{formatDate(a.adoption_date)}</div>
                </div>
                {a.adoption_fee > 0 && <div style={{ fontWeight: 700, color: 'var(--success)' }}>${a.adoption_fee}</div>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Full table */}
      <div className="card">
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)' }}>
          <div style={{ fontWeight: 700, fontSize: 15 }}>All Adoption Records ({adoptions.length})</div>
        </div>
        {adoptions.length === 0 ? (
          <div className="empty-state">
            <Heart size={44} />
            <h3>No adoptions yet</h3>
            <p>Adoption records will appear here once animals are adopted.</p>
          </div>
        ) : (
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Animal</th>
                  <th>Tag</th>
                  <th>Adopter Name</th>
                  <th>Contact</th>
                  <th>Date</th>
                  <th>Fee</th>
                  <th>Processed By</th>
                </tr>
              </thead>
              <tbody>
                {adoptions.map(a => (
                  <tr key={a.id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/animals/${a.animal_id}`)}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        {a.photo_url ? (
                          <img src={a.photo_url} alt="" className="animal-photo" />
                        ) : (
                          <div className="animal-photo photo-placeholder"><span style={{ fontSize: 20 }}>{getSpeciesEmoji(a.species)}</span></div>
                        )}
                        <div>
                          <div style={{ fontWeight: 700 }}>{a.animal_name}</div>
                          <div style={{ fontSize: 12, color: 'var(--text-muted)', textTransform: 'capitalize' }}>{a.species}</div>
                        </div>
                      </div>
                    </td>
                    <td><span className="tag-chip">{a.tag_number}</span></td>
                    <td style={{ fontWeight: 600 }}>{a.adopter_name}</td>
                    <td style={{ fontSize: 13, color: 'var(--text-muted)' }}>
                      {a.adopter_email && <div>{a.adopter_email}</div>}
                      {a.adopter_phone && <div>{a.adopter_phone}</div>}
                    </td>
                    <td>{formatDate(a.adoption_date)}</td>
                    <td style={{ fontWeight: 600, color: a.adoption_fee > 0 ? 'var(--success)' : 'var(--text-muted)' }}>
                      {a.adoption_fee > 0 ? `$${a.adoption_fee}` : 'Free'}
                    </td>
                    <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{a.processed_by_name || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
