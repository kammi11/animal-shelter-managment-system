import React, { useState, useEffect } from 'react';
import api from '../utils/api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid, Legend } from 'recharts';
import { formatDate, getSpeciesEmoji } from '../utils/helpers';
import { AlertTriangle, CheckCircle, TrendingUp, Clock } from 'lucide-react';

export default function ReportsPage() {
  const [summary, setSummary] = useState(null);
  const [overdueVaccinations, setOverdueVaccinations] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    Promise.all([
      api.get('/reports/summary'),
      api.get('/vaccinations/overdue/list'),
      api.get('/reports/alerts'),
    ]).then(([s, v, a]) => {
      setSummary(s.data);
      setOverdueVaccinations(v.data);
      setAlerts(a.data);
      setLoading(false);
    });
  }, []);

  const markAlertRead = async (id) => {
    await api.put(`/reports/alerts/${id}/read`);
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, is_read: 1 } : a));
  };

  const markAllRead = async () => {
    await api.put('/reports/alerts/read-all');
    setAlerts(prev => prev.map(a => ({ ...a, is_read: 1 })));
  };

  if (loading) return <div className="loading-center"><div className="spinner" /><span>Loading reports…</span></div>;

  const unreadAlerts = alerts.filter(a => !a.is_read);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Reports & Analytics</h1>
          <p className="page-subtitle">Shelter statistics and insights</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="tabs" style={{ marginBottom: 20, maxWidth: 500 }}>
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'vaccinations', label: `Overdue Vaccines (${overdueVaccinations.length})` },
          { id: 'alerts', label: `Alerts (${unreadAlerts.length})` },
        ].map(t => (
          <button key={t.id} className={`tab-btn ${activeTab === t.id ? 'active' : ''}`}
            onClick={() => setActiveTab(t.id)}>{t.label}</button>
        ))}
      </div>

      {/* Overview */}
      {activeTab === 'overview' && summary && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* KPIs */}
          <div className="grid-3">
            {[
              { label: 'Avg Stay (Days)', value: Math.round(summary.avg_stay_days?.avg_days || 0), icon: Clock, color: '#2563eb', bg: '#dbeafe' },
              { label: 'Vaccination Rate', value: `${summary.vaccination_compliance?.total_animals ? Math.round(summary.vaccination_compliance.vaccinated_animals / summary.vaccination_compliance.total_animals * 100) : 0}%`, icon: CheckCircle, color: '#059669', bg: '#d1fae5' },
              { label: 'Overdue Vaccines', value: summary.vaccination_compliance?.overdue || 0, icon: AlertTriangle, color: '#b45309', bg: '#fef3c7' },
            ].map(({ label, value, icon: Icon, color, bg }) => (
              <div className="card stat-card" key={label}>
                <div className="stat-icon" style={{ background: bg, color }}><Icon size={20} /></div>
                <div className="stat-value">{value}</div>
                <div className="stat-label">{label}</div>
              </div>
            ))}
          </div>

          {/* Charts row */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
            {/* Monthly intakes */}
            <div className="card" style={{ padding: 20 }}>
              <div className="section-title"><TrendingUp size={16} /> Monthly Intakes (12mo)</div>
              {summary.monthly_intakes.length === 0 ? (
                <div className="empty-state" style={{ padding: '30px 0' }}><p>No data</p></div>
              ) : (
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={[...summary.monthly_intakes].reverse()} margin={{ left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="count" fill="var(--primary)" name="Animals" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>

            {/* Monthly adoptions */}
            <div className="card" style={{ padding: 20 }}>
              <div className="section-title">Monthly Adoptions (12mo)</div>
              {summary.monthly_adoptions.length === 0 ? (
                <div className="empty-state" style={{ padding: '30px 0' }}><p>No data</p></div>
              ) : (
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={[...summary.monthly_adoptions].reverse()} margin={{ left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#be185d" name="Adoptions" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {/* Species breakdown table */}
          <div className="card" style={{ padding: 20 }}>
            <div className="section-title">Species Breakdown</div>
            <table className="table">
              <thead>
                <tr><th>Species</th><th>In Shelter</th><th>Adopted</th><th>Total</th></tr>
              </thead>
              <tbody>
                {summary.animals_by_species.map(s => (
                  <tr key={s.species}>
                    <td style={{ textTransform: 'capitalize', fontWeight: 600 }}>{getSpeciesEmoji(s.species)} {s.species}</td>
                    <td><span className="badge badge-info">{s.in_shelter}</span></td>
                    <td><span className="badge badge-success">{s.adopted}</span></td>
                    <td style={{ fontWeight: 700 }}>{s.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Longest stays */}
          <div className="card" style={{ padding: 20 }}>
            <div className="section-title"><Clock size={16} /> Longest Stays</div>
            <table className="table">
              <thead>
                <tr><th>Animal</th><th>Tag</th><th>Species</th><th>Entry Date</th><th>Days in Shelter</th></tr>
              </thead>
              <tbody>
                {summary.longest_stay.map(a => (
                  <tr key={a.tag_number}>
                    <td style={{ fontWeight: 700 }}>{a.name}</td>
                    <td><span className="tag-chip">{a.tag_number}</span></td>
                    <td style={{ textTransform: 'capitalize' }}>{getSpeciesEmoji(a.species)} {a.species}</td>
                    <td>{formatDate(a.entry_date)}</td>
                    <td>
                      <span style={{ fontWeight: 700, color: a.days_in_shelter > 60 ? 'var(--danger)' : a.days_in_shelter > 30 ? 'var(--warning)' : 'var(--text)' }}>
                        {a.days_in_shelter} days
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Overdue vaccinations */}
      {activeTab === 'vaccinations' && (
        <div>
          {overdueVaccinations.length === 0 ? (
            <div className="card">
              <div className="empty-state">
                <CheckCircle size={44} color="var(--success)" />
                <h3>All vaccinations up to date!</h3>
                <p>No overdue vaccinations at this time.</p>
              </div>
            </div>
          ) : (
            <>
              <div className="alert-banner alert-banner-warning" style={{ marginBottom: 16 }}>
                <AlertTriangle size={18} color="#92400e" style={{ flexShrink: 0 }} />
                <strong>{overdueVaccinations.length} vaccination{overdueVaccinations.length > 1 ? 's' : ''} overdue</strong>. Please schedule these animals for vaccination.
              </div>
              <div className="card">
                <table className="table">
                  <thead>
                    <tr><th>Animal</th><th>Tag</th><th>Species</th><th>Vaccine</th><th>Was Due</th><th>Days Overdue</th></tr>
                  </thead>
                  <tbody>
                    {overdueVaccinations.map(v => {
                      const daysOverdue = Math.floor((Date.now() - new Date(v.next_due_date)) / (1000 * 60 * 60 * 24));
                      return (
                        <tr key={v.id}>
                          <td style={{ fontWeight: 700 }}>{v.animal_name}</td>
                          <td><span className="tag-chip">{v.tag_number}</span></td>
                          <td style={{ textTransform: 'capitalize' }}>{getSpeciesEmoji(v.species)} {v.species}</td>
                          <td>{v.vaccine_name}</td>
                          <td style={{ color: 'var(--danger)' }}>{formatDate(v.next_due_date)}</td>
                          <td><span className="badge badge-danger">{daysOverdue} days</span></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}

      {/* Alerts */}
      {activeTab === 'alerts' && (
        <div>
          {alerts.length > 0 && unreadAlerts.length > 0 && (
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 12 }}>
              <button className="btn btn-ghost btn-sm" onClick={markAllRead}>Mark all read</button>
            </div>
          )}
          {alerts.length === 0 ? (
            <div className="card">
              <div className="empty-state">
                <CheckCircle size={44} color="var(--success)" />
                <h3>No alerts</h3>
                <p>Everything looks good!</p>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {alerts.map(a => (
                <div key={a.id} className="card" style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 12, opacity: a.is_read ? 0.6 : 1 }}>
                  <AlertTriangle size={18} color={a.is_read ? 'var(--text-muted)' : 'var(--warning)'} />
                  <div style={{ flex: 1 }}>
                    {a.animal_name && <span style={{ fontWeight: 700 }}>{a.animal_name}</span>}{' '}
                    <span style={{ fontSize: 14, color: 'var(--text-muted)' }}>{a.message}</span>
                  </div>
                  <span style={{ fontSize: 12, color: 'var(--text-light)' }}>{formatDate(a.created_at)}</span>
                  {!a.is_read && (
                    <button className="btn btn-ghost btn-sm" onClick={() => markAlertRead(a.id)}>
                      <CheckCircle size={14} /> Read
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <style>{`
        @media (max-width: 768px) {
          div[style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}
