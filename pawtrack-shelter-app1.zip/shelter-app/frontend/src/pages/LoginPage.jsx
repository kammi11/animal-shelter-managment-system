import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Eye, EyeOff, LogIn } from 'lucide-react';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: '', password: '' });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(form.username, form.password);
      toast.success('Welcome back!');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', background: 'var(--bg)',
      fontFamily: 'DM Sans, sans-serif',
    }}>
      {/* Left panel */}
      <div style={{
        flex: 1, background: 'var(--bg-sidebar)', display: 'flex',
        flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        padding: 60, position: 'relative', overflow: 'hidden',
      }} className="login-hero">
        {/* Decorative circles */}
        <div style={{
          position: 'absolute', width: 400, height: 400, borderRadius: '50%',
          background: 'rgba(245,166,35,0.08)', top: -100, right: -100,
        }} />
        <div style={{
          position: 'absolute', width: 250, height: 250, borderRadius: '50%',
          background: 'rgba(255,255,255,0.04)', bottom: 60, left: -60,
        }} />

        <div style={{ position: 'relative', textAlign: 'center', maxWidth: 380 }}>
          <div style={{ fontSize: 64, marginBottom: 24 }}>🐾</div>
          <h1 style={{
            fontFamily: 'DM Serif Display, serif', fontSize: 42,
            color: 'white', lineHeight: 1.1, marginBottom: 16,
          }}>PawTrack</h1>
          <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: 17, lineHeight: 1.6 }}>
            Complete Animal Shelter Management System. Track, care for, and find homes for every animal in your shelter.
          </p>

          <div style={{ marginTop: 48, display: 'flex', flexDirection: 'column', gap: 14 }}>
            {[
              { icon: '📋', text: 'Complete animal records & health tracking' },
              { icon: '💉', text: 'Vaccination schedules & reminders' },
              { icon: '❤️', text: 'Streamlined adoption management' },
              { icon: '📊', text: 'Reports & analytics dashboard' },
            ].map(({ icon, text }) => (
              <div key={text} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span style={{ fontSize: 20 }}>{icon}</span>
                <span style={{ color: 'rgba(255,255,255,0.7)', fontSize: 14 }}>{text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel - Login form */}
      <div style={{
        width: 460, display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 48, flexShrink: 0,
      }} className="login-form-panel">
        <div style={{ width: '100%', maxWidth: 380 }}>
          <h2 style={{ fontFamily: 'DM Serif Display, serif', fontSize: 30, marginBottom: 6 }}>
            Sign In
          </h2>
          <p style={{ color: 'var(--text-muted)', marginBottom: 36, fontSize: 15 }}>
            Enter your credentials to access the shelter system
          </p>

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            <div className="form-group">
              <label className="form-label">Username</label>
              <input
                className="form-control"
                placeholder="Enter your username"
                value={form.username}
                onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
                autoFocus required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  className="form-control"
                  type={showPw ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  style={{ paddingRight: 44 }}
                  required
                />
                <button type="button"
                  onClick={() => setShowPw(!showPw)}
                  style={{
                    position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
                    background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)',
                    padding: 4,
                  }}>
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button type="submit" className="btn btn-primary" disabled={loading}
              style={{ padding: '13px', justifyContent: 'center', marginTop: 8, fontSize: 15 }}>
              {loading ? <div className="spinner" style={{ width: 18, height: 18, borderWidth: 2 }} /> : <><LogIn size={18} /> Sign In</>}
            </button>
          </form>

          {/* Demo credentials */}
          <div style={{
            marginTop: 32, padding: 16, background: '#f0fdf4',
            border: '1px solid #bbf7d0', borderRadius: 10,
          }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#166534', marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              Demo Credentials
            </div>
            {[
              { label: 'Admin', user: 'admin', pw: 'admin123' },
              { label: 'Vet', user: 'drsmith', pw: 'vet123' },
              { label: 'Staff', user: 'jdoe', pw: 'staff123' },
            ].map(({ label, user, pw }) => (
              <div key={user} style={{ display: 'flex', gap: 8, marginBottom: 6, alignItems: 'center' }}>
                <span style={{ fontSize: 12, color: '#166534', fontWeight: 600, width: 44 }}>{label}:</span>
                <button onClick={() => setForm({ username: user, password: pw })}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    fontSize: 12, color: '#15803d', fontFamily: 'Courier New, monospace',
                    textDecoration: 'underline', padding: 0,
                  }}>
                  {user} / {pw}
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .login-hero { display: none !important; }
          .login-form-panel { width: 100% !important; }
        }
      `}</style>
    </div>
  );
}
