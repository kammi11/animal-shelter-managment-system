import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { formatDate, getSpeciesEmoji, getHealthBadgeClass, getHealthLabel, getStatusBadgeClass, getStatusLabel, isVaccinationOverdue } from '../utils/helpers';
import { Search, QrCode, X, AlertTriangle, CheckCircle, Syringe, Stethoscope, Heart } from 'lucide-react';
import toast from 'react-hot-toast';

export default function SearchPage() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [notFound, setNotFound] = useState(false);
  const [scanning, setScanning] = useState(false);
  const videoRef = useRef();
  const canvasRef = useRef();
  const streamRef = useRef();
  const scanIntervalRef = useRef();
  const inputRef = useRef();

  const search = async (tagNum) => {
    const tag = (tagNum || query).trim().toUpperCase();
    if (!tag) { toast.error('Enter a tag number'); return; }
    setLoading(true);
    setNotFound(false);
    setResult(null);
    try {
      const r = await api.get(`/animals/tag/${tag}`);
      setResult(r.data);
    } catch (err) {
      if (err.response?.status === 404) setNotFound(true);
      else toast.error('Search error');
    } finally { setLoading(false); }
  };

  const startScanner = async () => {
    setScanning(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      streamRef.current = stream;
      videoRef.current.srcObject = stream;
      videoRef.current.play();

      // Use jsQR for QR scanning
      const jsQR = (await import('jsqr')).default;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');

      scanIntervalRef.current = setInterval(() => {
        if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
          canvas.width = videoRef.current.videoWidth;
          canvas.height = videoRef.current.videoHeight;
          ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          if (code && code.data.startsWith('SHELTER:')) {
            const tagNum = code.data.replace('SHELTER:', '');
            stopScanner();
            setQuery(tagNum);
            search(tagNum);
          }
        }
      }, 300);
    } catch (err) {
      toast.error('Camera access denied');
      setScanning(false);
    }
  };

  const stopScanner = () => {
    clearInterval(scanIntervalRef.current);
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    setScanning(false);
  };

  useEffect(() => () => stopScanner(), []);

  return (
    <div style={{ maxWidth: 700, margin: '0 auto' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Tag Search</h1>
          <p className="page-subtitle">Look up any animal instantly using their unique tag number</p>
        </div>
      </div>

      {/* Search box */}
      <div className="card" style={{ padding: 28, marginBottom: 20 }}>
        <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
          <div className="search-bar" style={{ flex: 1, fontSize: 16 }}>
            <Search size={20} color="var(--text-muted)" />
            <input
              ref={inputRef}
              placeholder="Enter tag number (e.g. DOG-12345)…"
              value={query}
              onChange={e => setQuery(e.target.value.toUpperCase())}
              onKeyDown={e => e.key === 'Enter' && search()}
              style={{ fontSize: 16, fontFamily: 'Courier New, monospace', fontWeight: 700 }}
            />
            {query && <button onClick={() => { setQuery(''); setResult(null); setNotFound(false); }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: 2 }}><X size={16} /></button>}
          </div>
          <button className="btn btn-primary" onClick={() => search()} disabled={loading} style={{ minWidth: 100 }}>
            {loading ? <div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> : <><Search size={16} /> Search</>}
          </button>
          <button className="btn btn-ghost" onClick={scanning ? stopScanner : startScanner} title="Scan QR Code">
            <QrCode size={18} />
          </button>
        </div>

        {/* QR Scanner */}
        {scanning && (
          <div style={{ position: 'relative', borderRadius: 12, overflow: 'hidden', background: 'black', marginBottom: 12 }}>
            <video ref={videoRef} style={{ width: '100%', display: 'block', maxHeight: 260, objectFit: 'cover' }} playsInline />
            <canvas ref={canvasRef} style={{ display: 'none' }} />
            <div style={{
              position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
              pointerEvents: 'none',
            }}>
              <div style={{
                width: 180, height: 180, border: '3px solid #f5a623',
                borderRadius: 16, boxShadow: '0 0 0 9999px rgba(0,0,0,0.5)',
              }} />
            </div>
            <button onClick={stopScanner} style={{
              position: 'absolute', top: 12, right: 12, background: 'rgba(0,0,0,0.6)',
              border: 'none', borderRadius: 8, color: 'white', cursor: 'pointer', padding: '6px 10px',
              fontSize: 13, display: 'flex', alignItems: 'center', gap: 4,
            }}>
              <X size={14} /> Stop
            </button>
            <div style={{ position: 'absolute', bottom: 16, left: 0, right: 0, textAlign: 'center', color: 'white', fontSize: 13 }}>
              Point camera at a PawTrack QR code
            </div>
          </div>
        )}

        {/* Quick examples */}
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>Try:</span>
          {['DOG-', 'CAT-', 'BIR-'].map(prefix => (
            <span key={prefix} style={{ fontSize: 12, color: 'var(--primary)', cursor: 'pointer', fontFamily: 'Courier New, monospace' }}
              onClick={() => { setQuery(prefix); inputRef.current?.focus(); }}>
              {prefix}xxxxx
            </span>
          ))}
        </div>
      </div>

      {/* Result */}
      {notFound && (
        <div className="card" style={{ padding: 40, textAlign: 'center' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🔍</div>
          <h3 style={{ fontFamily: 'DM Serif Display, serif', fontSize: 22 }}>No animal found</h3>
          <p style={{ color: 'var(--text-muted)', marginTop: 8 }}>No animal with tag number <strong style={{ fontFamily: 'Courier New, monospace' }}>{query}</strong> was found.</p>
          <p style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 4 }}>Check the tag number and try again.</p>
        </div>
      )}

      {result && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Main info card */}
          <div className="card" style={{ padding: 24 }}>
            <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
              {result.photo_url ? (
                <img src={result.photo_url} alt={result.name} style={{ width: 100, height: 100, borderRadius: 14, objectFit: 'cover', border: '2px solid var(--border)', flexShrink: 0 }} />
              ) : (
                <div style={{ width: 100, height: 100, borderRadius: 14, background: 'var(--bg)', border: '2px dashed var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40, flexShrink: 0 }}>
                  {getSpeciesEmoji(result.species)}
                </div>
              )}

              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                  <span className="tag-chip">{result.tag_number}</span>
                  <span className={`badge ${getHealthBadgeClass(result.health_status)}`}>{getHealthLabel(result.health_status)}</span>
                  <span className={`badge ${getStatusBadgeClass(result.status)}`}>{getStatusLabel(result.status)}</span>
                </div>
                <h2 style={{ fontFamily: 'DM Serif Display, serif', fontSize: 26 }}>{result.name}</h2>
                <div style={{ color: 'var(--text-muted)', fontSize: 14, marginTop: 2, textTransform: 'capitalize' }}>
                  {getSpeciesEmoji(result.species)} {result.species}{result.breed ? ` · ${result.breed}` : ''} · {result.gender}
                  {result.color ? ` · ${result.color}` : ''}
                </div>

                <div style={{ display: 'flex', gap: 20, marginTop: 16, flexWrap: 'wrap' }}>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 26, fontFamily: 'DM Serif Display, serif', color: 'var(--primary-dark)' }}>{result.days_in_shelter}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase' }}>Days in Shelter</div>
                  </div>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 26, fontFamily: 'DM Serif Display, serif', color: 'var(--primary-dark)' }}>{result.vaccinations?.length || 0}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase' }}>Vaccinations</div>
                  </div>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 26, fontFamily: 'DM Serif Display, serif', color: 'var(--primary-dark)' }}>{result.medical_records?.length || 0}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase' }}>Med Records</div>
                  </div>
                </div>
              </div>

              <button className="btn btn-primary" onClick={() => navigate(`/animals/${result.id}`)}>
                View Full Profile →
              </button>
            </div>
          </div>

          {/* Quick details */}
          <div className="grid-2">
            {/* Vaccinations */}
            <div className="card" style={{ padding: 20 }}>
              <div className="section-title"><Syringe size={14} /> Vaccination Status</div>
              {result.vaccinations?.length === 0 ? (
                <div style={{ color: 'var(--text-muted)', fontSize: 14 }}>No vaccinations recorded</div>
              ) : result.vaccinations?.map(v => (
                <div key={v.id} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', paddingBottom: 10, marginBottom: 10, borderBottom: '1px solid var(--border)' }}>
                  {isVaccinationOverdue(v.next_due_date) ? <AlertTriangle size={16} color="var(--danger)" style={{ flexShrink: 0, marginTop: 1 }} /> : <CheckCircle size={16} color="var(--success)" style={{ flexShrink: 0, marginTop: 1 }} />}
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{v.vaccine_name}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Given: {formatDate(v.administered_date)}</div>
                    {v.next_due_date && <div style={{ fontSize: 12, color: isVaccinationOverdue(v.next_due_date) ? 'var(--danger)' : 'var(--success)', fontWeight: 600 }}>
                      {isVaccinationOverdue(v.next_due_date) ? '⚠️ Overdue: ' : 'Next: '}{formatDate(v.next_due_date)}
                    </div>}
                  </div>
                </div>
              ))}
            </div>

            {/* Recent medical */}
            <div className="card" style={{ padding: 20 }}>
              <div className="section-title"><Stethoscope size={14} /> Recent Medical</div>
              {result.medical_records?.length === 0 ? (
                <div style={{ color: 'var(--text-muted)', fontSize: 14 }}>No medical records</div>
              ) : result.medical_records?.slice(0, 4).map(r => (
                <div key={r.id} style={{ paddingBottom: 10, marginBottom: 10, borderBottom: '1px solid var(--border)' }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{r.title}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{r.record_type} · {formatDate(r.visit_date)}</div>
                  {r.medications && <div style={{ fontSize: 12, marginTop: 2 }}>💊 {r.medications}</div>}
                </div>
              ))}
            </div>
          </div>

          {/* Adoption info if adopted */}
          {result.adoption && (
            <div className="card" style={{ padding: 20, background: '#f0fdf4', borderColor: '#bbf7d0' }}>
              <div className="section-title"><Heart size={14} color="var(--success)" /> Adoption Information</div>
              <div style={{ display: 'flex', gap: 32, flexWrap: 'wrap', fontSize: 14 }}>
                <div><span style={{ color: 'var(--text-muted)' }}>Adopter: </span><strong>{result.adoption.adopter_name}</strong></div>
                <div><span style={{ color: 'var(--text-muted)' }}>Date: </span><strong>{formatDate(result.adoption.adoption_date)}</strong></div>
                {result.adoption.adopter_phone && <div><span style={{ color: 'var(--text-muted)' }}>Phone: </span><strong>{result.adoption.adopter_phone}</strong></div>}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
