import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { formatDate, getSpeciesEmoji, getHealthBadgeClass, getHealthLabel } from '../utils/helpers';
import { PawPrint, Heart, Syringe, AlertTriangle, TrendingUp, Clock, Plus, Search } from 'lucide-react';

const COLORS = ['#1a5c3a','#f5a623','#3b82f6','#ef4444','#8b5cf6','#10b981'];

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/animals/dashboard-stats').then(r => { setStats(r.data); setLoading(false); });
  }, []);

  if (loading) return <div className="loading-center"><div className="spinner" /><span>Loading dashboard…</span></div>;

  const healthData = [
    { name: 'Healthy', value: stats.healthy, color: '#10b981' },
    { name: 'Unhealthy / Treatment', value: stats.unhealthy, color: '#ef4444' },
  ].filter(d => d.value > 0);

  const vaccData = [
    { name: 'Vaccinated', value: stats.vaccinated, color: '#1a5c3a' },
    { name: 'Not Vaccinated', value: Math.max(0, stats.not_vaccinated), color: '#e5e0d8' },
  ].filter(d => d.value > 0);

  return (
    <div>
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">Welcome back, {user?.full_name} · {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-ghost" onClick={() => navigate('/search')}>
            <Search size={16} /> Tag Search
          </button>
          {['admin','staff','veterinarian'].includes(user?.role) && (
            <button className="btn btn-primary" onClick={() => navigate('/animals/add')}>
              <Plus size={16} /> Add Animal
            </button>
          )}
        </div>
      </div>

      {/* Alerts */}
      {stats.overdue_vaccinations > 0 && (
        <div className="alert-banner alert-banner-warning" style={{ marginBottom: 20 }}>
          <AlertTriangle size={18} color="#92400e" style={{ flexShrink: 0, marginTop: 1 }} />
          <div>
            <strong>{stats.overdue_vaccinations} vaccination{stats.overdue_vaccinations > 1 ? 's' : ''} overdue.</strong>{' '}
            Go to the <button onClick={() => navigate('/reports')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#92400e', fontWeight: 700, textDecoration: 'underline', padding: 0, fontFamily: 'inherit', fontSize: 'inherit' }}>Reports</button> page for details.
          </div>
        </div>
      )}

      {/* Stat cards */}
      <div className="grid-4" style={{ marginBottom: 24 }}>
        {[
          { label: 'Total Animals', value: stats.total, icon: PawPrint, color: '#1a5c3a', bg: '#d1fae5', sub: 'All time' },
          { label: 'In Shelter', value: stats.in_shelter, icon: Clock, color: '#2563eb', bg: '#dbeafe', sub: 'Currently housed' },
          { label: 'Adopted', value: stats.adopted, icon: Heart, color: '#be185d', bg: '#fce7f3', sub: 'Successfully placed' },
          { label: 'Overdue Vaccines', value: stats.overdue_vaccinations, icon: Syringe, color: stats.overdue_vaccinations > 0 ? '#b45309' : '#059669', bg: stats.overdue_vaccinations > 0 ? '#fef3c7' : '#d1fae5', sub: 'Need attention' },
        ].map(({ label, value, icon: Icon, color, bg, sub }) => (
          <div className="card stat-card" key={label}>
            <div className="stat-icon" style={{ background: bg, color }}>
              <Icon size={20} />
            </div>
            <div className="stat-value">{value}</div>
            <div className="stat-label">{label}</div>
            <div style={{ fontSize: 12, color: 'var(--text-light)', marginTop: 2 }}>{sub}</div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 20, marginBottom: 24 }}>
        {/* Health status */}
        <div className="card" style={{ padding: 20 }}>
          <div className="section-title">Health Status</div>
          {healthData.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={150}>
                <PieChart>
                  <Pie data={healthData} cx="50%" cy="50%" innerRadius={40} outerRadius={65}
                    dataKey="value" paddingAngle={3}>
                    {healthData.map((d, i) => <Cell key={i} fill={d.color} />)}
                  </Pie>
                  <Tooltip formatter={(v, n) => [v, n]} />
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {healthData.map(d => (
                  <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                    <div style={{ width: 10, height: 10, borderRadius: '50%', background: d.color, flexShrink: 0 }} />
                    <span style={{ flex: 1, color: 'var(--text-muted)' }}>{d.name}</span>
                    <span style={{ fontWeight: 700 }}>{d.value}</span>
                  </div>
                ))}
              </div>
            </>
          ) : <div className="empty-state" style={{ padding: '30px 0' }}><p>No data</p></div>}
        </div>

        {/* Vaccination status */}
        <div className="card" style={{ padding: 20 }}>
          <div className="section-title">Vaccination Status</div>
          {vaccData.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={150}>
                <PieChart>
                  <Pie data={vaccData} cx="50%" cy="50%" innerRadius={40} outerRadius={65}
                    dataKey="value" paddingAngle={3}>
                    {vaccData.map((d, i) => <Cell key={i} fill={d.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {vaccData.map(d => (
                  <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                    <div style={{ width: 10, height: 10, borderRadius: '50%', background: d.color, flexShrink: 0 }} />
                    <span style={{ flex: 1, color: 'var(--text-muted)' }}>{d.name}</span>
                    <span style={{ fontWeight: 700 }}>{d.value}</span>
                  </div>
                ))}
              </div>
            </>
          ) : <div className="empty-state" style={{ padding: '30px 0' }}><p>No data</p></div>}
        </div>

        {/* Species breakdown */}
        <div className="card" style={{ padding: 20 }}>
          <div className="section-title">Species Breakdown</div>
          {stats.species_breakdown.length > 0 ? (
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={stats.species_breakdown} layout="vertical" margin={{ left: 8 }}>
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="species" width={60} tick={{ fontSize: 12 }}
                  tickFormatter={v => `${getSpeciesEmoji(v)} ${v}`} />
                <Tooltip formatter={v => [v, 'Animals']} />
                <Bar dataKey="count" fill="var(--primary)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : <div className="empty-state" style={{ padding: '30px 0' }}><p>No data</p></div>}
        </div>
      </div>

      {/* Recent animals */}
      <div className="card">
        <div style={{ padding: '18px 20px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div className="section-title" style={{ margin: 0, border: 'none', padding: 0 }}>
            <TrendingUp size={16} /> Recently Added
          </div>
          <button className="btn btn-ghost btn-sm" onClick={() => navigate('/animals')}>View all</button>
        </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Animal</th>
                <th>Tag</th>
                <th>Species</th>
                <th>Health</th>
                <th>Days in Shelter</th>
                <th>Entry Date</th>
              </tr>
            </thead>
            <tbody>
              {stats.recent_animals.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 32 }}>No animals yet</td></tr>
              ) : stats.recent_animals.map(a => (
                <tr key={a.id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/animals/${a.id}`)}>
                  <td style={{ fontWeight: 600 }}>{a.name}</td>
                  <td><span className="tag-chip">{a.tag_number}</span></td>
                  <td>{getSpeciesEmoji(a.species)} {a.species}</td>
                  <td><span className={`badge ${getHealthBadgeClass(a.health_status)}`}>{getHealthLabel(a.health_status)}</span></td>
                  <td>{a.days_in_shelter} days</td>
                  <td style={{ color: 'var(--text-muted)' }}>{formatDate(a.entry_date)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <style>{`
        @media (max-width: 900px) {
          .grid-4 { grid-template-columns: repeat(2, 1fr) !important; }
          div[style*="grid-template-columns: 1fr 1fr 1fr"] { grid-template-columns: 1fr !important; }
        }
        @media (max-width: 500px) {
          .grid-4 { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}
