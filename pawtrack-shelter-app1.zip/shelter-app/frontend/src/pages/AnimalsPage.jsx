import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { formatDate, getSpeciesEmoji, getHealthBadgeClass, getHealthLabel, getStatusBadgeClass, getStatusLabel } from '../utils/helpers';
import { Plus, Search, Filter, PawPrint } from 'lucide-react';

const SPECIES_OPTIONS = ['dog','cat','bird','rabbit','hamster','fish','reptile','other'];
const STATUS_OPTIONS = ['in_shelter','adopted','transferred','deceased'];
const HEALTH_OPTIONS = ['healthy','unhealthy','under_treatment','critical'];

export default function AnimalsPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [animals, setAnimals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ search: '', status: 'in_shelter', species: '', health_status: '' });

  useEffect(() => { load(); }, [filters]);

  const load = async () => {
    setLoading(true);
    const params = {};
    if (filters.search) params.search = filters.search;
    if (filters.status) params.status = filters.status;
    if (filters.species) params.species = filters.species;
    if (filters.health_status) params.health_status = filters.health_status;
    const r = await api.get('/animals', { params });
    setAnimals(r.data);
    setLoading(false);
  };

  const setFilter = (key, val) => setFilters(f => ({ ...f, [key]: val }));

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Animals</h1>
          <p className="page-subtitle">{animals.length} animals found</p>
        </div>
        {['admin','staff','veterinarian'].includes(user?.role) && (
          <button className="btn btn-primary" onClick={() => navigate('/animals/add')}>
            <Plus size={16} /> Add Animal
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="card" style={{ padding: 16, marginBottom: 20 }}>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
          <div className="search-bar" style={{ flex: 1, minWidth: 200 }}>
            <Search size={16} color="var(--text-muted)" />
            <input placeholder="Search by name, tag, or breed…"
              value={filters.search}
              onChange={e => setFilter('search', e.target.value)} />
          </div>

          <select className="form-control" style={{ width: 'auto' }}
            value={filters.status} onChange={e => setFilter('status', e.target.value)}>
            <option value="">All Statuses</option>
            {STATUS_OPTIONS.map(s => <option key={s} value={s}>{getStatusLabel(s)}</option>)}
          </select>

          <select className="form-control" style={{ width: 'auto' }}
            value={filters.species} onChange={e => setFilter('species', e.target.value)}>
            <option value="">All Species</option>
            {SPECIES_OPTIONS.map(s => <option key={s} value={s}>{getSpeciesEmoji(s)} {s}</option>)}
          </select>

          <select className="form-control" style={{ width: 'auto' }}
            value={filters.health_status} onChange={e => setFilter('health_status', e.target.value)}>
            <option value="">All Health</option>
            {HEALTH_OPTIONS.map(h => <option key={h} value={h}>{getHealthLabel(h)}</option>)}
          </select>

          <button className="btn btn-ghost btn-sm"
            onClick={() => setFilters({ search: '', status: 'in_shelter', species: '', health_status: '' })}>
            Clear
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="card">
        {loading ? (
          <div className="loading-center"><div className="spinner" /></div>
        ) : animals.length === 0 ? (
          <div className="empty-state">
            <PawPrint size={48} />
            <h3>No animals found</h3>
            <p>Try adjusting your filters or add a new animal</p>
            {['admin','staff','veterinarian'].includes(user?.role) && (
              <button className="btn btn-primary" style={{ marginTop: 8 }} onClick={() => navigate('/animals/add')}>
                <Plus size={16} /> Add Animal
              </button>
            )}
          </div>
        ) : (
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Photo</th>
                  <th>Animal</th>
                  <th>Tag Number</th>
                  <th>Species / Breed</th>
                  <th>Gender</th>
                  <th>Health</th>
                  <th>Status</th>
                  <th>Days in Shelter</th>
                  <th>Location</th>
                  <th>Entry Date</th>
                </tr>
              </thead>
              <tbody>
                {animals.map(a => (
                  <tr key={a.id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/animals/${a.id}`)}>
                    <td>
                      {a.photo_url ? (
                        <img src={a.photo_url} alt={a.name} className="animal-photo" />
                      ) : (
                        <div className="animal-photo photo-placeholder">
                          <span style={{ fontSize: 20 }}>{getSpeciesEmoji(a.species)}</span>
                        </div>
                      )}
                    </td>
                    <td>
                      <div style={{ fontWeight: 700 }}>{a.name}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                        {a.age_years > 0 ? `${a.age_years}y` : ''} {a.age_months > 0 ? `${a.age_months}m` : ''}
                        {a.age_years === 0 && a.age_months === 0 ? 'Age unknown' : ''}
                      </div>
                    </td>
                    <td><span className="tag-chip">{a.tag_number}</span></td>
                    <td>
                      <div style={{ textTransform: 'capitalize' }}>{getSpeciesEmoji(a.species)} {a.species}</div>
                      {a.breed && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{a.breed}</div>}
                    </td>
                    <td style={{ textTransform: 'capitalize' }}>{a.gender}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <div className={`health-dot health-dot-${a.health_status}`} />
                        <span className={`badge ${getHealthBadgeClass(a.health_status)}`}>{getHealthLabel(a.health_status)}</span>
                      </div>
                    </td>
                    <td><span className={`badge ${getStatusBadgeClass(a.status)}`}>{getStatusLabel(a.status)}</span></td>
                    <td>
                      <span style={{ fontWeight: 600, color: a.days_in_shelter > 30 ? 'var(--danger)' : 'var(--text)' }}>
                        {a.days_in_shelter}d
                      </span>
                    </td>
                    <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{a.cage_location || '—'}</td>
                    <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDate(a.entry_date)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
