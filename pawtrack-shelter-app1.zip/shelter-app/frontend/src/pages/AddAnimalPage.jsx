import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { ArrowLeft, Upload, Camera, Save } from 'lucide-react';

const SPECIES = ['dog','cat','bird','rabbit','hamster','fish','reptile','other'];
const GENDERS = ['male','female','unknown'];

export default function AddAnimalPage() {
  const navigate = useNavigate();
  const fileRef = useRef();
  const [saving, setSaving] = useState(false);
  const [photoPreview, setPhotoPreview] = useState(null);
  const [form, setForm] = useState({
    tag_number: '', name: '', species: 'dog', breed: '', gender: 'male',
    age_years: 0, age_months: 0, weight_kg: '', color: '',
    entry_date: new Date().toISOString().split('T')[0],
    cage_location: '', notes: '', photo: null,
  });

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const handlePhoto = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast.error('Photo must be under 5MB'); return; }
    set('photo', file);
    setPhotoPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name) { toast.error('Animal name is required'); return; }

    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => {
        if (k === 'photo') { if (v) fd.append('photo', v); }
        else if (v !== '' && v !== null) fd.append(k, v);
      });

      const r = await api.post('/animals', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success(`${r.data.name} added successfully! Tag: ${r.data.tag_number}`);
      navigate(`/animals/${r.data.id}`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to add animal');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ maxWidth: 800, margin: '0 auto' }}>
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button className="btn btn-ghost btn-icon" onClick={() => navigate('/animals')}>
            <ArrowLeft size={18} />
          </button>
          <div>
            <h1 className="page-title">Add New Animal</h1>
            <p className="page-subtitle">Register a new animal into the shelter system</p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
          {/* Photo upload */}
          <div className="card" style={{ padding: 24, width: 220, flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', alignSelf: 'flex-start' }}>Photo</div>
            <div
              onClick={() => fileRef.current.click()}
              style={{
                width: 160, height: 160, borderRadius: 16,
                border: '2px dashed var(--border)', cursor: 'pointer',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                gap: 8, background: 'var(--bg)', overflow: 'hidden', transition: 'border-color 0.15s',
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--primary)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
            >
              {photoPreview ? (
                <img src={photoPreview} alt="Preview" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <>
                  <Camera size={32} color="var(--text-light)" />
                  <span style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center' }}>Click to upload photo</span>
                </>
              )}
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handlePhoto} />
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => fileRef.current.click()}>
              <Upload size={14} /> {photoPreview ? 'Change' : 'Upload'}
            </button>
            {photoPreview && (
              <button type="button" className="btn btn-ghost btn-sm"
                onClick={() => { setPhotoPreview(null); set('photo', null); }}>
                Remove
              </button>
            )}
          </div>

          {/* Main form */}
          <div style={{ flex: 1, minWidth: 300 }}>
            <div className="card" style={{ padding: 24, marginBottom: 16 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 18 }}>Basic Information</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <div className="grid-2">
                  <div className="form-group">
                    <label className="form-label">Tag Number <span style={{ color: 'var(--text-light)', fontWeight: 400 }}>(auto if blank)</span></label>
                    <input className="form-control" placeholder="e.g. DOG-12345"
                      value={form.tag_number} onChange={e => set('tag_number', e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Animal Name *</label>
                    <input className="form-control" placeholder="Enter name" required
                      value={form.name} onChange={e => set('name', e.target.value)} />
                  </div>
                </div>

                <div className="grid-2">
                  <div className="form-group">
                    <label className="form-label">Species *</label>
                    <select className="form-control" value={form.species} onChange={e => set('species', e.target.value)}>
                      {SPECIES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Breed</label>
                    <input className="form-control" placeholder="e.g. Labrador"
                      value={form.breed} onChange={e => set('breed', e.target.value)} />
                  </div>
                </div>

                <div className="grid-2">
                  <div className="form-group">
                    <label className="form-label">Gender *</label>
                    <select className="form-control" value={form.gender} onChange={e => set('gender', e.target.value)}>
                      {GENDERS.map(g => <option key={g} value={g}>{g}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Color</label>
                    <input className="form-control" placeholder="e.g. Brown & White"
                      value={form.color} onChange={e => set('color', e.target.value)} />
                  </div>
                </div>

                <div className="grid-2" style={{ gridTemplateColumns: '1fr 1fr 1fr 1fr' }}>
                  <div className="form-group">
                    <label className="form-label">Age (Years)</label>
                    <input className="form-control" type="number" min="0" max="30"
                      value={form.age_years} onChange={e => set('age_years', e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Age (Months)</label>
                    <input className="form-control" type="number" min="0" max="11"
                      value={form.age_months} onChange={e => set('age_months', e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Weight (kg)</label>
                    <input className="form-control" type="number" step="0.1" min="0"
                      placeholder="kg" value={form.weight_kg} onChange={e => set('weight_kg', e.target.value)} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Cage / Location</label>
                    <input className="form-control" placeholder="e.g. A-12"
                      value={form.cage_location} onChange={e => set('cage_location', e.target.value)} />
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Entry Date</label>
                  <input className="form-control" type="date"
                    value={form.entry_date} onChange={e => set('entry_date', e.target.value)} />
                </div>

                <div className="form-group">
                  <label className="form-label">Notes</label>
                  <textarea className="form-control" rows={3}
                    placeholder="Any special notes about this animal…"
                    value={form.notes} onChange={e => set('notes', e.target.value)} />
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button type="button" className="btn btn-ghost" onClick={() => navigate('/animals')}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? <div className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} /> : <Save size={16} />}
                {saving ? 'Saving…' : 'Add Animal'}
              </button>
            </div>
          </div>
        </div>
      </form>

      <style>{`
        @media (max-width: 640px) {
          div[style*="gridTemplateColumns: 1fr 1fr 1fr 1fr"] { grid-template-columns: 1fr 1fr !important; }
        }
      `}</style>
    </div>
  );
}
