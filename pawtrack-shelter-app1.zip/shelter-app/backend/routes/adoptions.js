const express = require('express');
const { getDb } = require('../db/database');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/adoptions
router.get('/', authenticateToken, (req, res) => {
  const db = getDb();
  const adoptions = db.prepare(`
    SELECT ad.*, a.name as animal_name, a.tag_number, a.species, a.breed, a.photo_url,
      u.full_name as processed_by_name
    FROM adoptions ad
    JOIN animals a ON ad.animal_id = a.id
    LEFT JOIN users u ON ad.processed_by = u.id
    ORDER BY ad.adoption_date DESC
  `).all();
  res.json(adoptions);
});

// POST /api/adoptions
router.post('/', authenticateToken, requireRole('admin', 'staff'), (req, res) => {
  const db = getDb();
  const { animal_id, adopter_name, adopter_email, adopter_phone, adopter_address, adoption_date, adoption_fee, notes } = req.body;

  if (!animal_id || !adopter_name) {
    return res.status(400).json({ error: 'animal_id and adopter_name are required' });
  }

  const animal = db.prepare('SELECT * FROM animals WHERE id = ?').get(animal_id);
  if (!animal) return res.status(404).json({ error: 'Animal not found' });
  if (animal.status === 'adopted') return res.status(409).json({ error: 'Animal already adopted' });

  const result = db.prepare(`
    INSERT INTO adoptions (animal_id, adopter_name, adopter_email, adopter_phone, adopter_address, adoption_date, adoption_fee, notes, processed_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    animal_id, adopter_name, adopter_email || null, adopter_phone || null,
    adopter_address || null,
    adoption_date || new Date().toISOString().split('T')[0],
    parseFloat(adoption_fee) || 0, notes || null, req.user.id
  );

  // Update animal status
  db.prepare("UPDATE animals SET status = 'adopted', updated_at = datetime('now') WHERE id = ?").run(animal_id);

  const adoption = db.prepare('SELECT * FROM adoptions WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(adoption);
});

// GET /api/adoptions/stats
router.get('/stats', authenticateToken, (req, res) => {
  const db = getDb();
  const stats = {
    total_adoptions: db.prepare("SELECT COUNT(*) as c FROM adoptions").get().c,
    this_month: db.prepare("SELECT COUNT(*) as c FROM adoptions WHERE strftime('%Y-%m', adoption_date) = strftime('%Y-%m', 'now')").get().c,
    total_fees: db.prepare("SELECT COALESCE(SUM(adoption_fee), 0) as c FROM adoptions").get().c,
    recent: db.prepare(`
      SELECT ad.*, a.name as animal_name, a.tag_number, a.species
      FROM adoptions ad JOIN animals a ON ad.animal_id = a.id
      ORDER BY ad.adoption_date DESC LIMIT 5
    `).all()
  };
  res.json(stats);
});

module.exports = router;
