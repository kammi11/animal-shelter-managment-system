const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const QRCode = require('qrcode');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../db/database');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// Multer setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '..', 'uploads');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

// Generate unique tag number
function generateTagNumber(species) {
  const prefix = species ? species.substring(0, 3).toUpperCase() : 'ANI';
  const num = Math.floor(Math.random() * 90000) + 10000;
  return `${prefix}-${num}`;
}

// GET /api/animals - list all
router.get('/', authenticateToken, (req, res) => {
  const db = getDb();
  const { status, species, health_status, search } = req.query;

  let query = `
    SELECT a.*, 
      CAST(julianday('now') - julianday(a.entry_date) AS INTEGER) as days_in_shelter,
      (SELECT COUNT(*) FROM vaccinations v WHERE v.animal_id = a.id) as vaccination_count,
      (SELECT COUNT(*) FROM medical_records m WHERE m.animal_id = a.id) as medical_records_count
    FROM animals a WHERE 1=1
  `;
  const params = [];

  if (status) { query += ' AND a.status = ?'; params.push(status); }
  if (species) { query += ' AND a.species = ?'; params.push(species); }
  if (health_status) { query += ' AND a.health_status = ?'; params.push(health_status); }
  if (search) {
    query += ' AND (a.tag_number LIKE ? OR a.name LIKE ? OR a.breed LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }

  query += ' ORDER BY a.created_at DESC';

  const animals = db.prepare(query).all(...params);
  res.json(animals);
});

// GET /api/animals/dashboard-stats
router.get('/dashboard-stats', authenticateToken, (req, res) => {
  const db = getDb();

  const stats = {
    total: db.prepare("SELECT COUNT(*) as c FROM animals WHERE status != 'deceased'").get().c,
    in_shelter: db.prepare("SELECT COUNT(*) as c FROM animals WHERE status = 'in_shelter'").get().c,
    healthy: db.prepare("SELECT COUNT(*) as c FROM animals WHERE health_status = 'healthy' AND status = 'in_shelter'").get().c,
    unhealthy: db.prepare("SELECT COUNT(*) as c FROM animals WHERE health_status != 'healthy' AND status = 'in_shelter'").get().c,
    adopted: db.prepare("SELECT COUNT(*) as c FROM animals WHERE status = 'adopted'").get().c,
    vaccinated: db.prepare(`
      SELECT COUNT(DISTINCT animal_id) as c FROM vaccinations 
      WHERE animal_id IN (SELECT id FROM animals WHERE status = 'in_shelter')
    `).get().c,
    not_vaccinated: 0,
    overdue_vaccinations: db.prepare(`
      SELECT COUNT(*) as c FROM vaccinations 
      WHERE next_due_date < date('now') AND next_due_date IS NOT NULL
      AND animal_id IN (SELECT id FROM animals WHERE status = 'in_shelter')
    `).get().c,
    recent_animals: db.prepare(`
      SELECT id, tag_number, name, species, health_status, entry_date,
        CAST(julianday('now') - julianday(entry_date) AS INTEGER) as days_in_shelter
      FROM animals WHERE status = 'in_shelter'
      ORDER BY created_at DESC LIMIT 5
    `).all(),
    alerts: db.prepare("SELECT * FROM alerts WHERE is_read = 0 ORDER BY created_at DESC LIMIT 10").all(),
    species_breakdown: db.prepare(`
      SELECT species, COUNT(*) as count FROM animals 
      WHERE status = 'in_shelter' GROUP BY species ORDER BY count DESC
    `).all()
  };

  stats.not_vaccinated = stats.in_shelter - stats.vaccinated;
  res.json(stats);
});

// GET /api/animals/tag/:tagNumber
router.get('/tag/:tagNumber', authenticateToken, (req, res) => {
  const db = getDb();
  const animal = db.prepare(`
    SELECT a.*, 
      CAST(julianday('now') - julianday(a.entry_date) AS INTEGER) as days_in_shelter
    FROM animals a WHERE a.tag_number = ?
  `).get(req.params.tagNumber);

  if (!animal) return res.status(404).json({ error: 'Animal not found' });

  const vaccinations = db.prepare('SELECT * FROM vaccinations WHERE animal_id = ? ORDER BY administered_date DESC').all(animal.id);
  const medical_records = db.prepare('SELECT * FROM medical_records WHERE animal_id = ? ORDER BY visit_date DESC').all(animal.id);
  const adoption = db.prepare('SELECT * FROM adoptions WHERE animal_id = ?').get(animal.id);

  res.json({ ...animal, vaccinations, medical_records, adoption });
});

// GET /api/animals/:id
router.get('/:id', authenticateToken, (req, res) => {
  const db = getDb();
  const animal = db.prepare(`
    SELECT a.*, 
      CAST(julianday('now') - julianday(a.entry_date) AS INTEGER) as days_in_shelter
    FROM animals a WHERE a.id = ?
  `).get(req.params.id);

  if (!animal) return res.status(404).json({ error: 'Animal not found' });

  const vaccinations = db.prepare('SELECT * FROM vaccinations WHERE animal_id = ? ORDER BY administered_date DESC').all(animal.id);
  const medical_records = db.prepare('SELECT * FROM medical_records WHERE animal_id = ? ORDER BY visit_date DESC').all(animal.id);
  const adoption = db.prepare('SELECT * FROM adoptions WHERE animal_id = ?').get(animal.id);

  res.json({ ...animal, vaccinations, medical_records, adoption });
});

// GET /api/animals/:id/qrcode
router.get('/:id/qrcode', authenticateToken, async (req, res) => {
  const db = getDb();
  const animal = db.prepare('SELECT tag_number, name FROM animals WHERE id = ?').get(req.params.id);
  if (!animal) return res.status(404).json({ error: 'Animal not found' });

  const qrData = `SHELTER:${animal.tag_number}`;
  const qrCodeDataUrl = await QRCode.toDataURL(qrData, { width: 300, margin: 2 });
  res.json({ qrCode: qrCodeDataUrl, tag_number: animal.tag_number, name: animal.name });
});

// POST /api/animals - create
router.post('/', authenticateToken, upload.single('photo'), (req, res) => {
  const db = getDb();
  const {
    tag_number, name, species, breed, gender, age_years, age_months,
    weight_kg, color, entry_date, cage_location, notes
  } = req.body;

  if (!name || !species || !gender) {
    return res.status(400).json({ error: 'Name, species, and gender are required' });
  }

  const tagNum = tag_number || generateTagNumber(species);

  // Check unique tag
  const existing = db.prepare('SELECT id FROM animals WHERE tag_number = ?').get(tagNum);
  if (existing) return res.status(409).json({ error: 'Tag number already exists' });

  const photo_url = req.file ? `/uploads/${req.file.filename}` : null;

  try {
    const result = db.prepare(`
      INSERT INTO animals (tag_number, name, species, breed, gender, age_years, age_months,
        weight_kg, color, photo_url, entry_date, cage_location, notes, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      tagNum, name, species, breed || null, gender,
      parseInt(age_years) || 0, parseInt(age_months) || 0,
      parseFloat(weight_kg) || null, color || null, photo_url,
      entry_date || new Date().toISOString().split('T')[0],
      cage_location || null, notes || null, req.user.id
    );

    const animal = db.prepare('SELECT * FROM animals WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(animal);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/animals/:id
router.put('/:id', authenticateToken, upload.single('photo'), (req, res) => {
  const db = getDb();
  const animal = db.prepare('SELECT * FROM animals WHERE id = ?').get(req.params.id);
  if (!animal) return res.status(404).json({ error: 'Animal not found' });

  const {
    name, species, breed, gender, age_years, age_months,
    weight_kg, color, entry_date, cage_location, status, health_status, notes
  } = req.body;

  const photo_url = req.file ? `/uploads/${req.file.filename}` : animal.photo_url;

  db.prepare(`
    UPDATE animals SET name=?, species=?, breed=?, gender=?, age_years=?, age_months=?,
      weight_kg=?, color=?, photo_url=?, entry_date=?, cage_location=?, 
      status=?, health_status=?, notes=?, updated_at=datetime('now')
    WHERE id=?
  `).run(
    name || animal.name,
    species || animal.species,
    breed !== undefined ? breed : animal.breed,
    gender || animal.gender,
    parseInt(age_years) >= 0 ? parseInt(age_years) : animal.age_years,
    parseInt(age_months) >= 0 ? parseInt(age_months) : animal.age_months,
    parseFloat(weight_kg) || animal.weight_kg,
    color !== undefined ? color : animal.color,
    photo_url,
    entry_date || animal.entry_date,
    cage_location !== undefined ? cage_location : animal.cage_location,
    status || animal.status,
    health_status || animal.health_status,
    notes !== undefined ? notes : animal.notes,
    req.params.id
  );

  const updated = db.prepare('SELECT * FROM animals WHERE id = ?').get(req.params.id);
  res.json(updated);
});

// DELETE /api/animals/:id (admin only)
router.delete('/:id', authenticateToken, requireRole('admin'), (req, res) => {
  const db = getDb();
  const animal = db.prepare('SELECT * FROM animals WHERE id = ?').get(req.params.id);
  if (!animal) return res.status(404).json({ error: 'Animal not found' });
  db.prepare('DELETE FROM animals WHERE id = ?').run(req.params.id);
  res.json({ message: 'Animal deleted' });
});

module.exports = router;
