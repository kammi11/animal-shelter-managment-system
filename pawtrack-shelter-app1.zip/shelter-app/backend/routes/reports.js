const express = require('express');
const { getDb } = require('../db/database');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/reports/summary
router.get('/summary', authenticateToken, (req, res) => {
  const db = getDb();

  const summary = {
    animals_by_species: db.prepare(`
      SELECT species, COUNT(*) as count, 
        SUM(CASE WHEN status='in_shelter' THEN 1 ELSE 0 END) as in_shelter,
        SUM(CASE WHEN status='adopted' THEN 1 ELSE 0 END) as adopted
      FROM animals GROUP BY species ORDER BY count DESC
    `).all(),

    animals_by_health: db.prepare(`
      SELECT health_status, COUNT(*) as count 
      FROM animals WHERE status='in_shelter' GROUP BY health_status
    `).all(),

    monthly_intakes: db.prepare(`
      SELECT strftime('%Y-%m', entry_date) as month, COUNT(*) as count
      FROM animals WHERE entry_date >= date('now', '-12 months')
      GROUP BY month ORDER BY month DESC
    `).all(),

    monthly_adoptions: db.prepare(`
      SELECT strftime('%Y-%m', adoption_date) as month, COUNT(*) as count, SUM(adoption_fee) as fees
      FROM adoptions WHERE adoption_date >= date('now', '-12 months')
      GROUP BY month ORDER BY month DESC
    `).all(),

    avg_stay_days: db.prepare(`
      SELECT AVG(CAST(julianday('now') - julianday(entry_date) AS INTEGER)) as avg_days
      FROM animals WHERE status='in_shelter'
    `).get(),

    longest_stay: db.prepare(`
      SELECT tag_number, name, species, entry_date,
        CAST(julianday('now') - julianday(entry_date) AS INTEGER) as days_in_shelter
      FROM animals WHERE status='in_shelter'
      ORDER BY entry_date ASC LIMIT 5
    `).all(),

    vaccination_compliance: db.prepare(`
      SELECT 
        COUNT(DISTINCT a.id) as total_animals,
        COUNT(DISTINCT v.animal_id) as vaccinated_animals,
        COUNT(DISTINCT CASE WHEN v.next_due_date < date('now') THEN v.animal_id END) as overdue
      FROM animals a
      LEFT JOIN vaccinations v ON a.id = v.animal_id
      WHERE a.status = 'in_shelter'
    `).get()
  };

  res.json(summary);
});

// GET /api/reports/alerts
router.get('/alerts', authenticateToken, (req, res) => {
  const db = getDb();
  const alerts = db.prepare(`
    SELECT al.*, a.name as animal_name, a.tag_number
    FROM alerts al
    LEFT JOIN animals a ON al.animal_id = a.id
    ORDER BY al.created_at DESC
  `).all();
  res.json(alerts);
});

// PUT /api/reports/alerts/:id/read
router.put('/alerts/:id/read', authenticateToken, (req, res) => {
  const db = getDb();
  db.prepare('UPDATE alerts SET is_read = 1 WHERE id = ?').run(req.params.id);
  res.json({ message: 'Alert marked as read' });
});

// PUT /api/reports/alerts/read-all
router.put('/alerts/read-all', authenticateToken, (req, res) => {
  const db = getDb();
  db.prepare('UPDATE alerts SET is_read = 1').run();
  res.json({ message: 'All alerts marked as read' });
});

module.exports = router;
