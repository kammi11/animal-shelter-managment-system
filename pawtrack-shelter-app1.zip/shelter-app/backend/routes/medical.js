const express = require('express');
const { getDb } = require('../db/database');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/medical/:animalId
router.get('/:animalId', authenticateToken, (req, res) => {
  const db = getDb();
  const records = db.prepare(`
    SELECT m.*, u.full_name as created_by_name 
    FROM medical_records m
    LEFT JOIN users u ON m.created_by = u.id
    WHERE m.animal_id = ? ORDER BY m.visit_date DESC
  `).all(req.params.animalId);
  res.json(records);
});

// POST /api/medical
router.post('/', authenticateToken, requireRole('admin', 'veterinarian', 'staff'), (req, res) => {
  const db = getDb();
  const { animal_id, record_type, title, description, vet_name, visit_date, medications, follow_up_date } = req.body;

  if (!animal_id || !title || !record_type) {
    return res.status(400).json({ error: 'animal_id, title, and record_type are required' });
  }

  const result = db.prepare(`
    INSERT INTO medical_records (animal_id, record_type, title, description, vet_name, visit_date, medications, follow_up_date, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(animal_id, record_type, title, description || null, vet_name || null,
    visit_date || new Date().toISOString().split('T')[0],
    medications || null, follow_up_date || null, req.user.id);

  // Update animal health status if needed
  if (req.body.health_status) {
    db.prepare("UPDATE animals SET health_status = ?, updated_at = datetime('now') WHERE id = ?")
      .run(req.body.health_status, animal_id);
  }

  const record = db.prepare('SELECT * FROM medical_records WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(record);
});

// PUT /api/medical/:id
router.put('/:id', authenticateToken, requireRole('admin', 'veterinarian'), (req, res) => {
  const db = getDb();
  const record = db.prepare('SELECT * FROM medical_records WHERE id = ?').get(req.params.id);
  if (!record) return res.status(404).json({ error: 'Record not found' });

  const { record_type, title, description, vet_name, visit_date, medications, follow_up_date } = req.body;

  db.prepare(`
    UPDATE medical_records SET record_type=?, title=?, description=?, vet_name=?, 
      visit_date=?, medications=?, follow_up_date=?
    WHERE id=?
  `).run(
    record_type || record.record_type,
    title || record.title,
    description !== undefined ? description : record.description,
    vet_name !== undefined ? vet_name : record.vet_name,
    visit_date || record.visit_date,
    medications !== undefined ? medications : record.medications,
    follow_up_date !== undefined ? follow_up_date : record.follow_up_date,
    req.params.id
  );

  res.json(db.prepare('SELECT * FROM medical_records WHERE id = ?').get(req.params.id));
});

// DELETE /api/medical/:id
router.delete('/:id', authenticateToken, requireRole('admin', 'veterinarian'), (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM medical_records WHERE id = ?').run(req.params.id);
  res.json({ message: 'Record deleted' });
});

module.exports = router;
