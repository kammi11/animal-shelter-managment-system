const express = require('express');
const { getDb } = require('../db/database');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/vaccinations/:animalId
router.get('/:animalId', authenticateToken, (req, res) => {
  const db = getDb();
  const records = db.prepare(`
    SELECT v.*, u.full_name as created_by_name 
    FROM vaccinations v
    LEFT JOIN users u ON v.created_by = u.id
    WHERE v.animal_id = ? ORDER BY v.administered_date DESC
  `).all(req.params.animalId);
  res.json(records);
});

// GET /api/vaccinations/overdue/list
router.get('/overdue/list', authenticateToken, (req, res) => {
  const db = getDb();
  const overdue = db.prepare(`
    SELECT v.*, a.name as animal_name, a.tag_number, a.species
    FROM vaccinations v
    JOIN animals a ON v.animal_id = a.id
    WHERE v.next_due_date < date('now') 
      AND v.next_due_date IS NOT NULL
      AND a.status = 'in_shelter'
    ORDER BY v.next_due_date ASC
  `).all();
  res.json(overdue);
});

// POST /api/vaccinations
router.post('/', authenticateToken, requireRole('admin', 'veterinarian', 'staff'), (req, res) => {
  const db = getDb();
  const { animal_id, vaccine_name, administered_date, next_due_date, administered_by, batch_number, notes } = req.body;

  if (!animal_id || !vaccine_name) {
    return res.status(400).json({ error: 'animal_id and vaccine_name are required' });
  }

  const result = db.prepare(`
    INSERT INTO vaccinations (animal_id, vaccine_name, administered_date, next_due_date, administered_by, batch_number, notes, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    animal_id, vaccine_name,
    administered_date || new Date().toISOString().split('T')[0],
    next_due_date || null,
    administered_by || null, batch_number || null, notes || null, req.user.id
  );

  // Create reminder alert if next_due_date set
  if (next_due_date) {
    db.prepare(`
      INSERT INTO alerts (animal_id, alert_type, message)
      SELECT ?, 'vaccination_due', 'Vaccination ' || ? || ' due on ' || ?
      WHERE NOT EXISTS (
        SELECT 1 FROM alerts WHERE animal_id = ? AND alert_type = 'vaccination_due' AND message LIKE ?
      )
    `).run(animal_id, vaccine_name, next_due_date, animal_id, `%${vaccine_name}%`);
  }

  const record = db.prepare('SELECT * FROM vaccinations WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(record);
});

// DELETE /api/vaccinations/:id
router.delete('/:id', authenticateToken, requireRole('admin', 'veterinarian'), (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM vaccinations WHERE id = ?').run(req.params.id);
  res.json({ message: 'Vaccination record deleted' });
});

module.exports = router;
