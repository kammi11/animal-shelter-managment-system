/**
 * Database layer using sql.js — pure JavaScript SQLite.
 * No native compilation required. Works on Windows without Visual Studio.
 */
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');

const DB_PATH = path.join(__dirname, '..', 'shelter.db');

let db = null;
let SQL = null;

// Save database to disk
function saveDb() {
  if (!db) return;
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

// Auto-save every 10 seconds
let autoSaveInterval = null;

function startAutoSave() {
  if (autoSaveInterval) return;
  autoSaveInterval = setInterval(() => {
    try { saveDb(); } catch (e) { /* ignore */ }
  }, 10000);
}

// Helper: run a query that modifies data
function run(sql, params = []) {
  db.run(sql, params);
  // Get last insert rowid
  const row = db.exec('SELECT last_insert_rowid() as id');
  const lastId = row[0] ? row[0].values[0][0] : null;
  saveDb();
  return { lastInsertRowid: lastId };
}

// Helper: get one row
function get(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  if (stmt.step()) {
    const cols = stmt.getColumnNames();
    const vals = stmt.get();
    stmt.free();
    const obj = {};
    cols.forEach((c, i) => { obj[c] = vals[i]; });
    return obj;
  }
  stmt.free();
  return null;
}

// Helper: get all rows
function all(sql, params = []) {
  const result = db.exec(sql, params);
  if (!result || result.length === 0) return [];
  const { columns, values } = result[0];
  return values.map(row => {
    const obj = {};
    columns.forEach((c, i) => { obj[c] = row[i]; });
    return obj;
  });
}

// Helper: exec (no return)
function exec(sql) {
  db.run(sql);
  saveDb();
}

// The db proxy object with familiar API
function getDb() {
  return { run, get, all, exec, prepare: makePrepare, saveDb };
}

// prepare() returns an object with .run(), .get(), .all()
function makePrepare(sql) {
  return {
    run: (...args) => {
      const params = args.length === 1 && Array.isArray(args[0]) ? args[0] : args;
      return run(sql, params);
    },
    get: (...args) => {
      const params = args.length === 1 && Array.isArray(args[0]) ? args[0] : args;
      return get(sql, params);
    },
    all: (...args) => {
      const params = args.length === 1 && Array.isArray(args[0]) ? args[0] : args;
      return all(sql, params);
    },
  };
}

async function initDb() {
  if (!SQL) {
    SQL = await require('sql.js')();
  }

  // Load existing database from disk or create new
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  // Enable foreign keys
  db.run('PRAGMA foreign_keys = ON');

  // Create tables
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      role TEXT NOT NULL,
      active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now'))
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS animals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tag_number TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      species TEXT NOT NULL,
      breed TEXT,
      gender TEXT NOT NULL,
      age_years INTEGER DEFAULT 0,
      age_months INTEGER DEFAULT 0,
      weight_kg REAL,
      color TEXT,
      photo_url TEXT,
      entry_date TEXT NOT NULL,
      cage_location TEXT,
      status TEXT NOT NULL DEFAULT 'in_shelter',
      health_status TEXT NOT NULL DEFAULT 'healthy',
      notes TEXT,
      created_by INTEGER,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS medical_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      animal_id INTEGER NOT NULL,
      record_type TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      vet_name TEXT,
      visit_date TEXT NOT NULL,
      medications TEXT,
      follow_up_date TEXT,
      created_by INTEGER,
      created_at TEXT DEFAULT (datetime('now'))
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS vaccinations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      animal_id INTEGER NOT NULL,
      vaccine_name TEXT NOT NULL,
      administered_date TEXT NOT NULL,
      next_due_date TEXT,
      administered_by TEXT,
      batch_number TEXT,
      notes TEXT,
      created_by INTEGER,
      created_at TEXT DEFAULT (datetime('now'))
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS adoptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      animal_id INTEGER NOT NULL,
      adopter_name TEXT NOT NULL,
      adopter_email TEXT,
      adopter_phone TEXT,
      adopter_address TEXT,
      adoption_date TEXT NOT NULL,
      adoption_fee REAL DEFAULT 0,
      notes TEXT,
      processed_by INTEGER,
      created_at TEXT DEFAULT (datetime('now'))
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      animal_id INTEGER,
      alert_type TEXT NOT NULL,
      message TEXT NOT NULL,
      is_read INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now'))
    )
  `);

  // Save schema
  saveDb();

  // Seed default users if not exist
  const adminExists = get('SELECT id FROM users WHERE username = ?', ['admin']);
  if (!adminExists) {
    const adminHash = bcrypt.hashSync('admin123', 10);
    run(`INSERT INTO users (username,password,full_name,email,role) VALUES (?,?,?,?,?)`,
      ['admin', adminHash, 'System Administrator', 'admin@shelter.com', 'admin']);

    const vetHash = bcrypt.hashSync('vet123', 10);
    run(`INSERT INTO users (username,password,full_name,email,role) VALUES (?,?,?,?,?)`,
      ['drsmith', vetHash, 'Dr. Sarah Smith', 'drsmith@shelter.com', 'veterinarian']);

    const staffHash = bcrypt.hashSync('staff123', 10);
    run(`INSERT INTO users (username,password,full_name,email,role) VALUES (?,?,?,?,?)`,
      ['jdoe', staffHash, 'John Doe', 'jdoe@shelter.com', 'staff']);

    saveDb();
    console.log('✅ Default users seeded');
    console.log('   admin / admin123');
    console.log('   drsmith / vet123');
    console.log('   jdoe / staff123');
  }

  startAutoSave();
  console.log('✅ Database initialized (sql.js — no compilation needed)');
  return getDb();
}

module.exports = { getDb, initDb };
