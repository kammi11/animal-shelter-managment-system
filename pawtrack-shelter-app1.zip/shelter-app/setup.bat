@echo off
echo.
echo  ==========================================
echo   PawTrack - Animal Shelter Management
echo   Setup Script (Windows)
echo  ==========================================
echo.

echo [1/3] Installing backend dependencies...
cd backend
call npm install
if %errorlevel% neq 0 (
    echo ERROR: Backend install failed. Make sure Node.js is installed.
    pause
    exit /b 1
)
cd ..

echo.
echo [2/3] Installing frontend dependencies...
cd frontend
call npm install
if %errorlevel% neq 0 (
    echo ERROR: Frontend install failed.
    pause
    exit /b 1
)
cd ..

echo.
echo [3/3] Setting up environment file...
if not exist backend\.env (
    copy backend\.env.example backend\.env
    echo      Created backend\.env - please edit it and add your settings
) else (
    echo      backend\.env already exists, skipping
)

echo.
echo  ==========================================
echo   Setup Complete!
echo  ==========================================
echo.
echo  To start the application:
echo.
echo   Terminal 1 (Backend):
echo     cd backend
echo     npm run dev
echo.
echo   Terminal 2 (Frontend):
echo     cd frontend
echo     npm run dev
echo.
echo   Then open: http://localhost:3000
echo.
echo  Default login: admin / admin123
echo.
pause
