#!/bin/bash

echo ""
echo "=========================================="
echo "  PawTrack - Animal Shelter Management"
echo "  Setup Script (Linux/Mac)"
echo "=========================================="
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed."
    echo "   Please install from https://nodejs.org (v18 or higher)"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js v18 or higher is required. You have $(node -v)"
    exit 1
fi

echo "✅ Node.js $(node -v) found"
echo ""

echo "[1/3] Installing backend dependencies..."
cd backend && npm install
if [ $? -ne 0 ]; then
    echo "❌ Backend install failed"
    exit 1
fi
cd ..
echo "✅ Backend dependencies installed"
echo ""

echo "[2/3] Installing frontend dependencies..."
cd frontend && npm install
if [ $? -ne 0 ]; then
    echo "❌ Frontend install failed"
    exit 1
fi
cd ..
echo "✅ Frontend dependencies installed"
echo ""

echo "[3/3] Setting up environment file..."
if [ ! -f backend/.env ]; then
    cp backend/.env.example backend/.env
    echo "✅ Created backend/.env — edit it to configure your settings"
else
    echo "   backend/.env already exists, skipping"
fi

echo ""
echo "=========================================="
echo "  Setup Complete! 🐾"
echo "=========================================="
echo ""
echo "To start the application, open two terminals:"
echo ""
echo "  Terminal 1 (Backend):"
echo "    cd backend && npm run dev"
echo ""
echo "  Terminal 2 (Frontend):"
echo "    cd frontend && npm run dev"
echo ""
echo "  Then open: http://localhost:3000"
echo ""
echo "  Default login: admin / admin123"
echo ""
